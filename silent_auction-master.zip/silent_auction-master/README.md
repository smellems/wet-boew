# Application Web d'enchère silencieuse - Silent Auction Web Application
Pour l'enchère silicieuse à PCH

This is for the silent auction at PCH


# Installation

Fonctionne bien sur une architecture LAMP (Linux-Apache-MySQL-PHP).

1.  Pour installation sur Debian et Ubuntu Vous avez besoin des packages suivant : apache2, php7.0, libapache2-mod-php7.0,  mysql-server
2.  Extraire les fichiers sur votre serveur web et vérifier que l'utilisateur du serveur peut lire les fichiers et répertoires.
3.  Créer une base de données et un utilisateur pour cette base de données.
4.  Importer le contenu du fichier (install/stpiadmindb.sql) dans la base de données pour créer les tables et les données initiales.
5.  Modifier l'information d'accès à la base de données dans le fichier: stpiadmin/includes/classes/bdd/clsbdd.php
6.  Modifier le nom de l'entreprise, les courriels et la page d'acceuil dans le fichier: stpiadmin/includes/includes.php

## Avec la ligne de commande

Préparer le serveur

    aptitude install apache2 php7.0 libapache2-mod-php7.0  mysql-server

Télécharger

    wget http://gitlab.ssc.etg.gc.ca/PCH/silent_auction/repository/archive.zip?ref=master

Extraire les fichiers

Établir une connexion à MySQL avec root

    mysql -u root -p

Créer la base de données et l'utilisateur

    CREATE DATABASE silent_auction;
    GRANT ALL ON silent_auction.* TO silent_auction@localhost IDENTIFIED BY 'password';
    QUIT;

Modifier le ficher

-  ../silent_auction/includes/database.php
