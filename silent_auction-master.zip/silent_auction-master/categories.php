<?php
	// Check language
  session_start();
  if(isset($_GET['logout'])){
		session_unset();
		session_destroy();
  }
  require_once(dirname(__FILE__) . "/includes/lang.php");
  
  // Database connections
  require_once(dirname(__FILE__) . "/includes/database.php");

  $leftNav = false;
 
  // Include texts and header
  require_once(dirname(__FILE__) . "/includes/text/" . $lang . ".php");

  // PHPMailer
  require_once(dirname(__FILE__) . "/lib/PHPMailer/PHPMailerAutoload.php");
  
  $pageTitle = 'Manage categories';
  require_once(dirname(__FILE__) . "/includes/header-" . $lang . ".php");
  date_default_timezone_set("America/Toronto");
 
  if (isset($_POST['nom']) && isset($_POST['pwd'])) {
	if(empty($_POST['nom']) ||  empty($_POST['pwd'])){
		if(empty($_POST['nom']))
			echo '<p><strong>You need to type the user name!</strong></p>';
		if(empty($_POST['pwd']))
			echo '<p><strong>You need to type the password!</strong></p>';
	}else{
		$sqll = 'SELECT Password FROM mysql.user where User="' . $_POST['nom'] . '"';
		
		$resl = mysqli_query($conn, $sqll);
		if ($row = mysqli_fetch_assoc($resl))
		 {
			 if(mysqli_connect($servername,$_POST['nom'], $_POST['pwd'], $dbname))
			 {
				 if(!isset($_SESSION['username']))
				  $_SESSION['username'] = $_POST['nom'];
				 if(!isset($_SESSION['password']))
				  $_SESSION['password'] = $_POST['pwd'];
			}else{
				echo '<p><strong>The password is not correct, please confirm!</strong></p>';
			}
		}else
		   echo '<p><strong>This user is not registed yet! please register first!</strong></p>';
	}		
  }
	
  
  if(isset($_GET['act'])){
	 $act = $_GET['act'];
	 if($act=="add"){
		 if(empty( $_POST['fname'] ) || empty( $_POST['ename'] )){
			 if(empty( $_POST['fname'] ))
				 echo '<p><strong>You need to type the French name</strong></p>';
			 if(empty( $_POST['ename'] ))
				 echo '<p><strong>You need to type the English name</strong></p>';
		 }else{
			 $sqlc = 'INSERT INTO categories(id,name_fr,name_en,created,modified) VALUES(NULL,"' . $_POST['fname'] . '","' . $_POST['ename'] . '",now(), NULL)';
			 $resultc = mysqli_query($conn, $sqlc);
			 if($resultc) 
				 echo '<p><strong>A new category is added successfully!</strong></p>';	 
			 else
				 echo mysqli_error($sqlc);  
		}
	 }else if($act=="del"){
		$id = $_GET['checkindex'];
		$sqlc = 'delete from categories where id=' . $id;
 		$resultc = mysqli_query($conn, $sqlc);
		if($resultc) 
			 echo '<p><strong>The category ' . $id . ' is deleted successfully!</strong></p>';	 
		else
			 echo mysqli_error($sqlc);  		
	 }else if($act=="save"){
		$id = $_GET['checkindex'];
		$fr_name = 'fname' . $id;
		$en_name = 'ename' . $id;		
		if(empty( $_POST[$fr_name] ) || empty( $_POST[$en_name] )){
			 if(empty( $_POST[$fr_name] ))
				 echo '<p><strong>You need to type the French name for category ' . $id . '</strong></p>';
			 if(empty( $_POST[$en_name] ))
				 echo '<p><strong>You need to type the English name for category ' . $id . '</strong></p>';			
		}else{
			$sqlc = 'update categories set name_fr="' . $_POST[$fr_name] . '", name_en="' . $_POST[$en_name] . '", modified=now() where id=' . $id;
			$resultc = mysqli_query($conn, $sqlc);
			if($resultc) 
				 echo '<p><strong>The category ' . $id . ' is updated successfully!</strong></p>';	 
			else
				 echo mysqli_error($sqlc);  	
		}		 
	 }
  }
  if(isset($_SESSION['username']) && isset($_SESSION['password'])) {
?>
   <p><strong><a href="categories.php?logout=true">Log out</a></strong></p>
	<form name="frm_category" action="categories.php" method="post">
        <table class="wet-boew-tables" data-wet-boew='{"bSort": false}'>
		 <thead>
	     <tr>
		    <th>&nbsp;</th>
		    <th> Category ID</th>
		    <th> French name</th>
			<th> English name</th>
			<th> Date created</th>
			<th> Date modified</th>
			<th> Actions</th>
		 </tr>
		 </thead>
		 <tbody>
		  <?php
			if(isset($_GET['checkindex']) && $_GET['checkindex']==0){
				print('<tr class="background-highlight">');
			    print('<td><input type="radio" checked name="checkindex" value="0" onchange="window.location.href=\'categories.php?checkindex=\'+this.value"></td>');
			}
			else{
				print('<tr>');		 
				print('<td><input type="radio" name="checkindex" value="0" onchange="window.location.href=\'categories.php?checkindex=\'+this.value"></td>');
			}
		 ?>
		    <td>&nbsp;</td>
		    <td><input type="text" size=50 id="fname" name="fname"></td>
            <td><input type="text" size=50 id="ename" name="ename"></td>	
 			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>
			    <input type="submit" value="Add" onclick="frm_category.action='categories.php?act=add'; return true;" />
			</td>
		 </tr>	
         <?php
		    
           	$sql = 'select id, name_fr,name_en,created, modified from categories' ;
			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_assoc($result)) {
					$id = $row["id"];
					if(isset($_GET['checkindex']) && $_GET['checkindex']==$id){
						print('<tr class="background-highlight">');
						print('<td><input type="radio" checked name="checkindex" value="' . $id . '" onchange="window.location.href=\'categories.php?checkindex=\'+this.value"> </td>');
					}
					else{
						print('<tr>');
						print('<td><input type="radio" name="checkindex" value="' . $id . '" onchange="window.location.href=\'categories.php?checkindex=\'+this.value"> </td>');
					}

     	?>		        
				   <td> <?php print($row["id"]); ?>  </td>
				   <td> <?php 
				        print('<input type="text" size=50 id="fname' . $id . '" name="fname' . $id . '" value="' . $row["name_fr"] . '">'); 
				   ?>  </td>
				   <td> <?php 
				        print('<input type="text" size=50 id="ename' . $id . '" name="ename' . $id . '" value="' . $row["name_en"] . '">'); 
				        ?>  </td>
				   <td> <?php print($row["created"]); ?>  </td>
				   <td> <?php print($row["modified"]); ?>  </td>
				   <td>
				    <input type="submit" value="Save"  onclick="frm_category.action='categories.php?act=save&checkindex=<?php print($row["id"]); ?>'; return true;" />
					<input type="submit" value="Delete" onclick="frm_category.action='categories.php?act=del&checkindex=<?php print($row["id"]); ?>'; return true;" />
				   </td>
				</tr>
        <?php		
				}
            }
		 ?>	
       </tbody>		 
	   </table>
		
    </form>
<?php
  }else{
?>      
	<form name="frm_login" method="post" action="categories.php">
		<input type="hidden" id="srt" name="srt" value="">
		<label for="nom">User name:</label>
		<input type="text" id="nom" name="nom" size="50"><br><br>
		<label for="pwd">Password:</label>
		<input type="password" id="pwd" name="pwd" size="50"><br><br>
		<input type="submit" value="Login">
	</form>
<?php  
     }  
     $lastmod = getlastmod();
     require_once(dirname(__FILE__) . "/includes/footer-" . $lang . ".php");
     
     mysqli_close($conn);
?>
 

