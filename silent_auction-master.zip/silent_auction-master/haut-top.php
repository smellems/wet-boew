<?php

// Check language
  require_once(dirname(__FILE__) . "/includes/lang.php");
  
  // Database connections
  require_once(dirname(__FILE__) . "/includes/database.php");

  $leftNav = true;
 
  // Include texts and header
  require_once(dirname(__FILE__) . "/includes/text/" . $lang . ".php");

  // PHPMailer
  require_once(dirname(__FILE__) . "/lib/PHPMailer/PHPMailerAutoload.php");
  
  $pageTitle = $arrTxt['toptwo'];
  require_once(dirname(__FILE__) . "/includes/header-" . $lang . ".php");
  
  /** Error reporting */
  error_reporting(E_ALL);
  ini_set('display_errors', TRUE);
  ini_set('display_startup_errors', TRUE);
  define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

  /** Include PHPExcel */
  require_once dirname(__FILE__) . '/lib/PHPExcel/Classes/PHPExcel.php';
  
  $count = 1;
  $objPHPExcel = new PHPExcel();
  $objPHPExcel->getProperties()->setCreator($arrTxt["title"])
							 ->setLastModifiedBy($arrTxt["title"])
							 ->setTitle($arrTxt["title"])
							 ->setSubject($arrTxt["title"])
							 ->setDescription($arrTxt["title"])
							 ->setKeywords($arrTxt["title"])
							 ->setCategory($arrTxt["title"]);
  if (isset($_GET['top_num']))     
      $top_num = $_GET['top_num'];
  else  
	  $top_num = 2;

?>
  <p><a href="<?php print('http://' .  $_SERVER['HTTP_HOST'] . getSitePath() . '/reports/haut-top-' . $lang . '.xlsx'); ?>"><?php print($arrTxt["hexcel"]); ?></a></p>
  
  <form name="form_winbid" id="form_winbid" method="post" action="haut-top.php">
    <label for="top_num"><?php print($arrTxt['winbids']); ?> :          
		<select class="background-highlight" id="top_num" name="top-num" onChange="window.location.href='haut-top.php?top_num='+this.value">
		<?php 
		  if($top_num==1)  print('<option selected="selected" value="1">1</option>');
		  else print('<option value="1">1</option>');
		  if($top_num==2)  print('<option selected="selected" value="2">2</option>');
		  else print('<option value="2">2</option>');
		  if($top_num==3)  print('<option selected="selected" value="3">3</option>');
		  else print('<option value="3">3</option>');
		  if($top_num==4)  print('<option selected="selected" value="4">4</option>');
		  else print('<option value="4">4</option>');
		  if($top_num==5)  print('<option selected="selected" value="5">5</option>');
		  else print('<option value="5">5</option>');
	   ?>
		 </select>
	 </label>
  </form>
  
  <div class="span-6"><table class="wet-boew-tables" data-wet-boew='{"aaSorting": [[0, "asc"],[2, "desc"]]}'>
     <thead>
	  <tr> 
	      <th><?php print($arrTxt["itemname"]); ?></th>
		  <th><?php print($arrTxt["email"]); ?></th>
		  <th><?php print($arrTxt["price"]); ?></th>
		  <th>Date</th>
		  <th><?php print( $arrTxt["status"]); ?></th>
       </tr>
  	 </thead>
    <tbody>
<?php
  	
  $sql1 = "SELECT id, name_" . $lang . " as name FROM items ORDER BY name_" . $lang;
  $result1 = mysqli_query($conn, $sql1);
  if (mysqli_num_rows($result1) > 0) {
	while($row = mysqli_fetch_assoc($result1)) {  
  	    $sql2 = "SELECT * FROM bids WHERE status=1 AND item_id=" . $row["id"] . " ORDER BY price desc limit " . $top_num;
	    $result2 = mysqli_query($conn, $sql2);
		if (mysqli_num_rows($result2) > 0) {
			while($bids =mysqli_fetch_assoc($result2)) {
			  if($bids['price']>0){
				  print('<tr><td><a href="http://' . $_SERVER['HTTP_HOST'] . getSitePath() . '/placer-place.php?item_id=' . $row["id"] . '">' . $row["name"] . '</a></td>' );		   
				  print("<td>" . $bids['email'] . "</td>" );
				  print("<td>" . format_currency($lang,$bids['price']) . "$</td>" );
				  print("<td>" . $bids['modified'] . "</td>" );
				  print("<td>" . $arrTxt["confirmed"] . "</td></tr>" );
								  
				  $objPHPExcel->setActiveSheetIndex(0)
							  ->setCellValue('A' . $count, $row["name"])
							  ->setCellValue('B' . $count, $bids['email'])
							  ->setCellValue('C' . $count, $bids['modified'])
							  ->setCellValue('D' . $count, $arrTxt["confirmed"]);
				  $count++;			  

			   } //end if
			} //end while
		}// end if	


    }
  }
    // Rename worksheet
	$objPHPExcel->getActiveSheet()->setTitle($arrTxt["title"]);

	// Set active sheet index to the first sheet, so Excel opens this as the first sheet
	$objPHPExcel->setActiveSheetIndex(0);
	
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	$objWriter->save(dirname(__FILE__) . "/reports/haut-2-top-" .$lang . ".xlsx");

?>
   </tbody>
  </table>
 </div>
 <div class="clear"></div>  
 <?php
  $lastmod = getlastmod();
  require_once(dirname(__FILE__) . "/includes/footer-" . $lang . ".php");
 
  mysqli_close($conn);
  
?>