<?php
	// Database connections
	require_once(dirname(__FILE__) . "/includes/database.php");

	$sql = "SELECT picture FROM items WHERE id='" . $_GET["item_id"] . "'";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0)
	{
		if ($row = mysqli_fetch_assoc($result))
		{
			if (!empty($row["picture"]))
			{
				$img = $row["picture"];
				header("Content-Type: image/jpeg");
				print($img);
			}
			else
			{
				header("location: ./includes/images/genericItem.png");
			}
		}
	}

	mysqli_close($conn);
