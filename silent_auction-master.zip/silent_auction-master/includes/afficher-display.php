<?php
  if (!isset($item_id)) 
    $item_id = 1;

  $highest_confirmed = getHighestConfirmedBid($item_id);
  $highest_noconfirm = getHighestUnconfirmedBid($item_id);
   
  $sql = "SELECT * FROM bids where item_id=" . $item_id . " ORDER BY modified DESC, created DESC";
  $result = mysqli_query($conn, $sql);
    
  if (mysqli_num_rows($result) > 0) {
?>
       <div class="span-6"><table class="wet-boew-tables" data-wet-boew='{"aaSorting": [[0, "desc"],[2, "desc"]]}'>
        <thead>
		      <tr> 
          
              <th><?php print($arrTxt["weight"]); ?></th>
              <th><?php print($arrTxt["email"]); ?></th>
              <th><?php print($arrTxt["price"]); ?></th>
              <th>Date</th>
              <th><?php print( $arrTxt["status"]); ?></th>
          </tr>
    	 </thead>
       <tbody>
     <?php
 			 while($bids =mysqli_fetch_assoc($result)) {
              //$weight = $bids['weight'];
              $email = $bids['email'];
              $price = $bids['price'];
              $created = $bids['created'];
              $modified = $bids['modified'];
              $status = $bids['status'];   
              if($status<2){
				  if($status==1) {
					  $valid = $arrTxt["confirmed"];
				   }else{
					  $valid = $arrTxt["nonconfirmed"];
				   }  
				   
				  if($price==$highest_confirmed && $status==1) {
					  print('<tr class="background-highlight">');
					  $weight = "**";               
				  } else if($price==$highest_noconfirm && $status==0) {
					  print('<tr class="background-light">');
					  $weight = "*";
				  } else {
					  $weight = "";
					  print('<tr>');
				  } 
					   
				  print("<td>" . $weight . "</td>" );
				  print("<td>" . $email . "</td>" );
				  print("<td>" . format_currency($lang,$price) . "$</td>" );
				  if(empty($modified))
						 print("<td>" . $created . "</td>" );
				  else
						 print("<td>" . $modified . "</td>" );
				  print("<td>" . $valid . "</td></tr>" );
			   }
			} //end while
    ?>
    </tbody>
   </table>
   </div>
   <div class="clear"></div>
   <?php
   } //end if
  
   ?>
