<div class="clear"></div>
<dl id="gcwu-date-mod">
<dt>Date modified:</dt><dd><span><time><?php  print(date("Y-m-d", $lastmod)); ?></time></span></dd>
</dl>

<div class="clear"></div>
<!-- MainContentEnd -->
</div>
</div>

<?php 
    if($leftNav==true)
    {
        require_once(dirname(__FILE__) . "/leftnav-categories.php");
    }
?>

</div></div>

<div id="wb-foot">
<div id="wb-foot-in"><footer>
<h2 id="wb-nav">Footer</h2>
<!-- FooterStart --><nav>
<div id="gcwu-sft">
<h3>Site footer</h3>
<div id="gcwu-sft-in"><section>
<div class="span-2">
<h4 class="gcwu-col-head">Useful Links</h4>
<ul>
<li><a href="http://ourpch.pch.gc.ca/eng//1358683381035/1358683381037">Emergencies</a></li>
<li><a href="http://sage-geds.tpsgc-pwgsc.gc.ca/cgi-bin/direct500/eng/TE?FN=index.htm">Government Directory (GEDS)</a></li>
<li><a href="http://ourpch.pch.gc.ca/eng//1434547199704">CIOB</a></li>
<li><a href="http://ourpch.pch.gc.ca/eng//1358684229538#a1">Accessibility Centre</a></li>
<li><a href="http://ourpch.pch.gc.ca/eng//1358684229560#a1">Building Maintenance</a></li>
<li><a href="http://pch.gc.ca/pc-ch/cntct/index-eng.cfm">PCH Enquiry Centre</a></li>
<li><a href="http://pch.gc.ca/eng/1266037002102/1265993639778">PCH.GC.CA</a></li>
<li><a href="http://jobs-emplois.gc.ca/index-eng.htm">jobs.gc.ca</a></li>
</ul>
</div>
</section><section>
<div class="span-2">
<h4 class="gcwu-col-head">About Us</h4>
<ul>
<li><a href="http://ourpch.pch.gc.ca/eng//1353606348084">Sectors and Branches</a></li>
<li><a href="http://ourpch.pch.gc.ca/eng//1358530878930">Regions</a></li>
<li><a href="http://pch.gc.ca/eng/1266433674232/1266389969960">Portfolio Organizations</a></li>
<li><a href="http://ourpch.pch.gc.ca/eng//1358353630470">About the DMs</a></li>
<li><a href="http://ourpch.pch.gc.ca/eng//1359635568006">PCH Management</a></li>
<li><a href="http://ourpch.pch.gc.ca/eng//1358363142147">Vision and Mission</a></li>
</ul>
</div>
</section><section>
<div class="span-2">
<h4 class="gcwu-col-head">Contact Us</h4>
<ul>
<li><a href="http://ourpch.pch.gc.ca/eng//1358519429926">Intranet Web Team</a></li>
<li><a href="http://ourpch.pch.gc.ca/eng//1396621064264">News@PCH</a></li>
</ul>
</div>
</section><section>
<div class="span-2">
<h4 class="gcwu-col-head">Stay Connected</h4>
<ul>
<li><a href="http://www.facebook.com/CdnHeritage">Facebook</a></li>
<li><a href="http://twitter.com/CdnHeritage">Twitter</a></li>
<li><a href="http://www.youtube.com/CdnHeritage">YouTube</a></li>
<li><a href="http://www.flickr.com/photos/canadianheritage-patrimoinecanadien">Flickr</a></li>
</ul>
</div>
</section><!--<div id="gcwu-tctr">
<ul>
<li class="gcwu-tc"><a rel="license" href="#">Terms and conditions</a></li>
<li class="gcwu-tr"><a href="#">Transparency</a></li>
</ul>
</div>--></div>
</div>
</nav><!-- FooterEnd --></footer></div>
</div>
</div>
<!-- ScriptsStart -->
<script src="./lib/wet-boew/js/settings.js" type="text/javascript"></script>
<script src="./lib/wet-boew/theme-gcwu-intranet/js/theme-ie-min.js" type="text/javascript"></script>
<script src="./lib/wet-boew/js/pe-ap-min.js" type="text/javascript"></script>
<script src="./lib/wet-boew/js/jquerymobile/jquery.mobile-ie.min.js" type="text/javascript"></script>
<!-- ScriptsEnd -->

  </body>
</html>
