<div class="clear"></div>

<dl id="gcwu-date-mod">
<dt>Date de modification :</dt><dd><span><time><?php  print(date("Y-m-d", $lastmod)); ?></time></span></dd>
</dl>

<div class="clear"></div>
<!-- MainContentEnd -->
</div></div>

<?php 
    if($leftNav==true)
    {
        require_once(dirname(__FILE__) . "/leftnav-categories.php");
    }
?>

</div></div>

<div id="wb-foot"><div id="wb-foot-in"><footer><h2 id="wb-nav">Pied de page</h2>
<!-- FooterStart -->
<nav>
<div id="gcwu-sft">
<h3>Pied de page du site</h3>
<div id="gcwu-sft-in"><section>
<div class="span-2">
<h4 class="gcwu-col-head">Liens utiles</h4>
<ul>
<li><a href="http://ourpch.pch.gc.ca/fra/1358683381035/1358683381037">Urgence</a></li>
<li><a href="http://sage-geds.gc.ca/cgi-bin/direct500/fra/TF?FN=index.htm">Annuaire du gouvernement (SAGE)</a></li>
<li><a href="http://ourpch.pch.gc.ca/fra/1434547199704">DGDPI</a></li>
<li><a href="http://ourpch.pch.gc.ca/fra/1358684229538#a1">Centre d&rsquo;accessibilit&eacute;</a></li>
<li><a href="http://ourpch.pch.gc.ca/fra/1358684229560#a1">Entretien des installations</a></li>
<li><a href="http://pch.gc.ca/pc-ch/cntct/index-fra.cfm">Centre de renseignements de PCH</a></li>
<li><a href="http://pch.gc.ca/fra/1266037002102/1265993639778">PCH.GC.CA</a></li>
<li><a href="http://jobs-emplois.gc.ca/index-fra.htm">emplois.gc.ca</a></li>
</ul>
</div>
</section><section>
<div class="span-2">
<h4 class="gcwu-col-head">&Agrave; propos de nous</h4>
<ul>
<li><a href="http://ourpch.pch.gc.ca/fra/1353606348084">Secteurs et directions g&eacute;n&eacute;rales</a></li>
<li><a href="http://ourpch.pch.gc.ca/fra/1358530878930">R&eacute;gions</a></li>
<li><a href="http://pch.gc.ca/fra/1266433674232/1266389969960">Organismes du portefeuille</a></li>
<li><a href="http://ourpch.pch.gc.ca/fra/1358353630470">&Agrave; propos des SMs</a></li>
<li><a href="http://ourpch.pch.gc.ca/fra/1359635568006">Gestion de PCH</a></li>
<li><a href="http://ourpch.pch.gc.ca/fra/1358363142147">Vision et Mission</a></li>
</ul>
</div>
</section><section>
<div class="span-2">
<h4 class="gcwu-col-head">Pour nous joindre</h4>
<ul>
<li><a href="http://ourpch.pch.gc.ca/fra/1358519429926">&Eacute;quipe Web Intranet</a></li>
<li><a href="http://ourpch.pch.gc.ca/fra/1396621064264">Nouvelles@PCH</a></li>
</ul>
</div>
</section><section>
<div class="span-2">
<h4 class="gcwu-col-head">Restez branch&eacute;s</h4>
<ul>
<li><a href="http://www.facebook.com/Patrimoinecdn">Facebook</a></li>
<li><a href="https://twitter.com/Patrimoinecdn">Twitter</a></li>
<li><a href="http://www.youtube.com/Patrimoinecdn">YouTube</a></li>
<li><a href="http://www.flickr.com/photos/canadianheritage-patrimoinecanadien">Flickr</a></li>
</ul>
</div>
</section><!--<div id="gcwu-tctr">
<ul>
<li class="gcwu-tc"><a rel="license" href="#">Terms and conditions</a></li>
<li class="gcwu-tr"><a href="#">Transparency</a></li>
</ul>
</div>--></div>
</div>
</nav>
<!-- FooterEnd -->
</footer></div></div>
</div>

<!-- ScriptsStart -->
<script src="./lib/wet-boew/js/settings.js" type="text/javascript"></script>
<script src="./lib/wet-boew/theme-gcwu-intranet/js/theme-ie-min.js" type="text/javascript"></script>
<script src="./lib/wet-boew/js/pe-ap-min.js" type="text/javascript"></script>
<script src="./lib/wet-boew/js/jquerymobile/jquery.mobile-ie.min.js" type="text/javascript"></script>
<!-- ScriptsEnd -->

</body>
</html>
