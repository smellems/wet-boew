<?php
  require_once(dirname(__FILE__) . "/functions.php");
?>
<!DOCTYPE html>
<!--[if IE 7]><html lang="en" class="no-js ie7"><![endif]-->
<!--[if IE 8]><html lang="en" class="no-js ie8"><![endif]-->
<!--[if gt IE 8]><!-->
<html lang="en" class="no-js">
<!--<![endif]-->
<head>
<meta charset="utf-8" />
<!-- Web Experience Toolkit (WET) / Boîte à outils de l'expérience Web (BOEW)
www.tbs.gc.ca/ws-nw/wet-boew/terms / www.sct.gc.ca/ws-nw/wet-boew/conditions -->
<title><?php print($pageTitle); ?> </title>

<meta name="description"  content="<?php print($arrTxt["metadescription"]); ?>" />

<meta name="keywords"  content="<?php print($arrTxt["metakeywords"]); ?>" />

<meta name="dcterms.creator"  content="Government of Canada; Canadian Heritage; Communications" />

<meta name="dcterms.language"  content="en" />

<meta name="dcterms.subject" title="gccore" content="<?php print $arrTxt["metasubject"]; ?>" />

<meta name="dcterms.title"  content="<?php print($pageTitle); ?>" />

<meta name="dcterms.issued" title="W3CDTF" content="<?php print $arrTxt["metaissued"]; ?>" />

<meta name="dcterms.modified" title="W3CDTF" content="<?php print $arrTxt["metamodified"]; ?>" />

<!--[if lte IE 8]>
<link rel="shortcut icon" href="./lib/wet-boew/theme-gcwc-intranet/images/favicon.ico" />
<script src="./lib/wet-boew/js/jquery-ie.min.js"></script>
<script src="./lib/wet-boew/js/polyfills/html5shiv-min.js"></script>
<link rel="stylesheet" href="./lib/wet-boew/grids/css/util-ie-min.css" />
<link rel="stylesheet" href="./lib/wet-boew/js/css/pe-ap-ie-min.css" />
<link rel="stylesheet" href="./lib/wet-boew/theme-gcwu-intranet/css/theme-ie-min.css" />
<noscript><link rel="stylesheet" href="./lib/wet-boew/theme-gcwu-intranet/css/theme-ns-ie-min.css" /></noscript>
<![endif]-->

<!--[if gt IE 8]><!-->
<link rel="icon" type="image/x-icon" href="./lib/wet-boew/theme-gcwc-intranet/images/favicon.ico" />
<script src="./lib/wet-boew/js/jquery.min.js"></script>
<link rel="stylesheet" href="./lib/wet-boew/grids/css/util-min.css" />
<link rel="stylesheet" href="./lib/wet-boew/js/css/pe-ap-min.css" />
<link rel="stylesheet" href="./lib/wet-boew/theme-gcwu-intranet/css/theme-min.css" />
<noscript><link rel="stylesheet" href="./lib/wet-boew/theme-gcwu-intranet/css/theme-ns-min.css" /></noscript>
<!--<![endif]-->

<!-- CustomScriptsCSSStart -->

<link rel="stylesheet" href="./includes/css/silent_auction.css" />
<script src="./includes/js/silent_auction.js"></script>
 
<!-- Google Tag Manager -->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37012805-14']);
  _gaq.push(['_setDomainName', 'none']);
  _gaq.push(['_setAllowLinker', true]);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!-- End Google Tag Manager -->

<!-- CustomScriptsCSSEnd -->

</head>

<body>
<?php
 if ($leftNav==true)
 {
  print("<div id=\"wb-body-sec\">");
 } else {
  print("<div id=\"wb-body\">");
 }
?>
<div id="wb-skip">
<ul id="wb-tphp">
<li id="wb-skip1"><a href="#wb-cont">Skip to main content</a></li>
<li id="wb-skip2"><a href="#wb-nav">Skip to footer</a></li>
</ul>
</div>
<div id="wb-head">
<div id="wb-head-in"><header><!-- HeaderStart --><nav>
<div id="gcwu-gcnb">
<h2>Intranet navigation bar</h2>
<div id="gcwu-gcnb-in">

<div id="gcwu-intranetnb"><div id="gcwu-intranetnb-in">
<ul>
<li id="gcwu-gcnb1"><a href="http://ourpch.pch.gc.ca/eng/1358519429926">Contact Us</a></li>
<li id="gcwu-gcnb-lang"><a lang="fr" href="<?php if(empty($_SERVER['QUERY_STRING'])) print('?lang=fr'); 
                                                 else {  
                                                     if(strpos($_SERVER['REQUEST_URI'], 'lang=en')!==false)
                                                        print(str_replace('lang=en','lang=fr',$_SERVER['REQUEST_URI']));
                                                      else 
                                                        print($_SERVER['REQUEST_URI'] . '&lang=fr');
                                                 } ?>">Fran&ccedil;ais</a></li>
</ul>
</div></div>

<div id="gcwu-gcnb-fip">
<div id="gcwu-sig"><div id="gcwu-sig-in"><object data="./lib/wet-boew/theme-gcwu-intranet/images/sig-blk-en.svg" role="img" tabindex="-1" aria-label="Government of Canada" type="image/svg+xml"><img src="/silent_auction/css/theme-gcwu-intranet/images/sig-en.png" alt="Government of Canada" /></object></div></div>
<div id="gcwu-wmms"><div id="gcwu-wmms-in"><object data="./lib/wet-boew/theme-gcwu-intranet/images/wmms-intra.svg" role="img" tabindex="-1" aria-label="Symbol of the Government of Canada" type="image/svg+xml"><img src="/silent_auction/css/theme-gcwu-intranet/images/wmms-alt.png" alt="Symbol of the Government of Canada" /></object></div></div>
</div>

</div></div>
</nav>

<div id="gcwu-bnr" role="banner"><div id="gcwu-bnr-in">
<div id="gcwu-title"><p id="gcwu-title-in"><a href="http://ourpch.pch.gc.ca/eng/1353586926687">Our PCH</a></p></div>
<section role="search">
<div id="gcwu-srchbx">
<h2>Search</h2>
<form action="http://ourpch.pch.gc.ca/eng/1353608394203/s/q.s" method="get"><div id="gcwu-srchbx-in">
<label for="gcwu-srch">Search</label> <input name="l7c1l3" type="hidden" value="eng"> <input name="S_S20RCH.l1ng91g3" type="hidden" value="eng"> <input id="gcwu-srch" maxlength="150" name="S_F8LLT2XT" size="27" type="text">
<input id="gcwu-srch-submit" name="cn-search-submit" type="submit" value="Search">
</div></form>
</div></section>

</div></div><nav>
<div id="gcwu-psnb">
<h2>Site navigation bar</h2>
<div id="gcwu-psnb-in">
<div class="wet-boew-menubar mb-mega">
<div>
<ul class="mb-menu">
<li><section>
<h3><a class="nav" href="http://ourpch.pch.gc.ca/eng/1353587823087">The Department</a></h3>
<div class="mb-sm">
<div class="span-2">
<ul>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1353604849509">DMs' Corner</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1353606348084">Sectors and Branches</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1358530878930">Regional Offices</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1359064138380">Groups and Committees</a></li>
<li><a class="nav" href="http://www.pch.gc.ca/eng/1266433674232/1266389969960">Portfolio Organizations</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1396621064264">News at PCH</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1359120126018">Spotlight</a></li>
</ul>
</div>
<div class="clear"></div>
</div>
</section></li>
<li>
<div><a class="nav" href="http://ourpch.pch.gc.ca/eng/1358683375832">Human Resources</a></div>
</li>
<li><section>
<h3><a class="nav" href="http://ourpch.pch.gc.ca/eng/1353594273868">Services</a></h3>
<div class="mb-sm">
<div class="span-2">
<ul>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1358684229538#1a">Accessibility Centre</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1354728792254">ATIP</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1355144232734">Audit</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1434547199704">CIOB Services</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1359060060923">Communications</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1355854915837">Contracting and Materiel Management</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1425496315641">Evaluation</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1358684229560">Real Property and Accomodations</a></li>
</ul>
</div>
<div class="span-2">
<ul>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1359903545873">Financial Management</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1357230196849">Gs&amp;Cs Centre of Expertise</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1438894248978">Kiosks and Diplays</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1359818160026">Legal Services</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1433768794990">Library</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1359744092518">Ministerial Correspondence</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1359122136524">Office of Values and Ethics</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1358683381079">Corporate Security</a></li>
</ul>
</div>
<div class="clear"></div>
</div>
</section></li>
<li><section>
<h3><a class="nav" href="http://ourpch.pch.gc.ca/eng/1353606791530">Reference and Tools</a></h3>
<div class="mb-sm">
<div class="span-2">
<ul>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1363374424588">Boardroom Reservations</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1358684229560#a1">Building Maintenance</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1354743644642">CCM Mercury</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1359134796078#num4">Corporate Look Templates</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1358683381035">Emergencies</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1359663880774">Employee Assistance Program</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1361977377849">Employee Orientation</a></li>
<li><a class="nav" href="http://gcconnex.gc.ca/">GCconnex</a></li>
<li><a class="nav" href="http://www.gcpedia.gc.ca/gcwiki/index.php?title=Main%20Page&setlang=en">GCPedia</a></li>
<li><a class="nav" href="http://sagegc-gedsgc.tpsgc-pwgsc.gc.ca/cgi-bin/web500/eng/TE?FN=index.htm">Government Directory (GEDS)</a></li>
</ul>
</div>
<div class="span-2">
<ul>
<li><a class="nav" href="http://www.noslangues-ourlanguages.gc.ca/index-eng.php">Language Portal of Canada</a></li>
<li><a class="nav" href="http://vubisweb.pch.gc.ca/iguana/www.main.cls?surl=search&p=f8616668-2589-11e5-8bee-505687299100&language=eng">Library Catalogue</a></li>
<li><a class="nav" href="http://mediascope.pch.gc.ca/default.asp?Lang=E">MediaScope</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1358683381046">Peoplesoft</a></li>
<li><a class="nav" href="http://gcintranet.tpsgc-pwgsc.gc.ca/gc/rem/awr-cwa-eng.html">Phoenix and Compensation Web Applications</a></li>
<li><a class="nav" href="https://portal-portail.tbs-sct.gc.ca/home-eng.aspx">TBS Applications</a></li>
<li><a class="nav" href="http://btb.termiumplus.gc.ca/tpv2alpha/alpha-eng.html?lang=eng">Termium</a></li>
<li><a class="nav" href="https://order.translationbureau.gc.ca/">Translation Bureau</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1429717894281">Travel</a></li>
<!-- <li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1363184242329">Dictionaries</a></li> --></ul>
</div>
<div class="clear"></div>
</div>
</section></li>
<li><section>
<h3><a class="nav" href="http://ourpch.pch.gc.ca/eng/1431449799027">Innovation</a></h3>
<div class="mb-sm">
<div class="span-2">
<ul>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1431449799027">Innovation at PCH</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1431027903604">Blueprint 2020</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1431538821469">Innovation Fund</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1431109336342">Innovative Projects</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1431539569692">Successes and Failures </a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/eng/1431540339450">Library</a></li>
</ul>
</div>
<div class="clear"></div>
</div>
</section></li>
</ul>
</div>
</div>
</div>
</div>
<!-- Breadcrums -->
<div id="gcwu-bc"><h2><?php print($arrTxt['breadcrumb']); ?></h2><div id="gcwu-bc-in">
	<ol>
		<li><a href="http://notrepch-ourpch/eng/1353586926687"><?php print($arrTxt['home']); ?></a></li>
		<?php
		if ($pageTitle != $arrTxt['title'])
			print("<li><a href=\"./\">" . $arrTxt['title'] . "</a></li>");
		
		if($pageTitle == $arrTxt['viewanitem'] || $pageTitle == $arrTxt['confirmbid'] )
			print("<li><a href=\"./?category_id=all\">" . $arrTxt['categories'] . "</a></li>");
		
		?>
		<li><?php print($pageTitle); ?></li>
	</ol>
</div></div>

</nav><!-- HeaderEnd --></header></div>
</div>
<div id="wb-core">
<div class="equalize" id="wb-core-in">
<div role="main" id="wb-main">
<div id="wb-main-in"><!-- MainContentStart -->
<h1 id="wb-cont"><?php print($pageTitle); ?></h1>
