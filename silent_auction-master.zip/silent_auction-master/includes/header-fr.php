<?php
  require_once(dirname(__FILE__) . "/functions.php");
?>
<!DOCTYPE html>
<!--[if IE 7]><html lang="fr" class="no-js ie7"><![endif]-->
<!--[if IE 8]><html lang="fr" class="no-js ie8"><![endif]-->
<!--[if gt IE 8]><!-->
<html lang="fr" class="no-js">
<!--<![endif]-->
<head>
<meta charset="utf-8" />
<!-- Web Experience Toolkit (WET) / Boîte à outils de l'expérience Web (BOEW)
www.tbs.gc.ca/ws-nw/wet-boew/terms / www.sct.gc.ca/ws-nw/wet-boew/conditions -->
<title><?php print($pageTitle); ?></title>

<meta name="description"  content="<?php print($arrTxt["metadescription"]); ?>" />

<meta name="keywords"  content="<?php print($arrTxt["metakeywords"]); ?>" />

<meta name="dcterms.creator"  content="Government of Canada; Canadian Heritage; Communications" />

<meta name="dcterms.language"  content="fr" />

<meta name="dcterms.subject" title="gccore" content="<?php print($arrTxt["metadescription"]); ?>" />

<meta name="dcterms.title"  content="<?php print($pageTitle); ?>" />

<meta name="dcterms.issued" title="W3CDTF" content="<?php print $arrTxt["metaissued"]; ?>" />

<meta name="dcterms.modified" title="W3CDTF" content="<?php print $arrTxt["metamodified"]; ?>" />

<!--[if lte IE 8]>
<link rel="shortcut icon" href="./lib/wet-boew/theme-gcwc-intranet/images/favicon.ico" />
<script src="./lib/wet-boew/js/jquery-ie.min.js"></script>
<script src="./lib/wet-boew/js/polyfills/html5shiv-min.js"></script>
<link rel="stylesheet" href="./lib/wet-boew/grids/css/util-ie-min.css" />
<link rel="stylesheet" href="./lib/wet-boew/js/css/pe-ap-ie-min.css" />
<link rel="stylesheet" href="./lib/wet-boew/theme-gcwu-intranet/css/theme-ie-min.css" />
<noscript><link rel="stylesheet" href="./lib/wet-boew/theme-gcwu-intranet/css/theme-ns-ie-min.css" /></noscript>
<![endif]-->

<!--[if gt IE 8]><!-->
<link rel="icon" type="image/x-icon" href="./lib/wet-boew/theme-gcwc-intranet/images/favicon.ico" />
<script src="./lib/wet-boew/js/jquery.min.js"></script>
<link rel="stylesheet" href="./lib/wet-boew/grids/css/util-min.css" />
<link rel="stylesheet" href="./lib/wet-boew/js/css/pe-ap-min.css" />
<link rel="stylesheet" href="./lib/wet-boew/theme-gcwu-intranet/css/theme-min.css" />
<noscript><link rel="stylesheet" href="./lib/wet-boew/theme-gcwu-intranet/css/theme-ns-min.css" /></noscript>
<!--<![endif]-->

<!-- CustomScriptsCSSStart -->

<link rel="stylesheet" href="./includes/css/silent_auction.css" />
<script src="./includes/js/silent_auction.js"></script>

<!-- Google Tag Manager -->
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-37012805-14']);
  _gaq.push(['_setDomainName', 'none']);
  _gaq.push(['_setAllowLinker', true]);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!-- End Google Tag Manager -->

<!-- CustomScriptsCSSEnd -->

</head>

<body>
<?php
 if ($leftNav==true)
 {
  print("<div id=\"wb-body-sec\">");
 } else {
  print("<div id=\"wb-body\">");
 }
?>
<div id="wb-skip">
<ul id="wb-tphp">
<li id="wb-skip1"><a href="#wb-cont">Passer au contenu principal</a></li>
<li id="wb-skip2"><a href="#wb-nav">Passer au pied de page</a></li>
</ul>
</div>

<div id="wb-head"><div id="wb-head-in"><header>
<!-- HeaderStart --> 
<nav>
<div id="gcwu-gcnb">
<h2>Barre de navigation d'intranet</h2>
<div id="gcwu-gcnb-in">

<div id="gcwu-intranetnb"><div id="gcwu-intranetnb-in">
<ul>
<li id="gcwu-gcnb1"><a href="http://ourpch.pch.gc.ca/fra/1358519429926">Pour nous joindre</a></li>
<li id="gcwu-gcnb-lang"><a lang="en" href="<?php if(empty($_SERVER['QUERY_STRING'])) print('?lang=en'); 
                                                 else {  
                                                     if(strpos($_SERVER['REQUEST_URI'], 'lang=fr')!==false)
                                                        print(str_replace('lang=fr','lang=en',$_SERVER['REQUEST_URI']));
                                                      else 
                                                        print($_SERVER['REQUEST_URI'] . '&lang=en');
                                                 } ?>">English</a></li>
</ul>
</div></div>


<div id="gcwu-gcnb-fip">
<div id="gcwu-sig"><div id="gcwu-sig-in"><object data="./lib/wet-boew/theme-gcwu-intranet/images/sig-blk-fr.svg" role="img" tabindex="-1" aria-label="Gouvernement du Canada" type="image/svg+xml"><img src="/silent_auction/css/theme-gcwu-intranet/images/sig-fr.png" alt="Gouvernement du Canada" /></object></div></div>
<div id="gcwu-wmms"><div id="gcwu-wmms-in"><object data="./lib/wet-boew/theme-gcwu-intranet/images/wmms-intra.svg" role="img" tabindex="-1" aria-label="Symbole du gouvernement du Canada" type="image/svg+xml"><img src="/silent_auction/css/theme-gcwu-intranet/images/wmms-alt.png" alt="Symbole du gouvernement du Canada" /></object></div></div>
</div>

</div></div>
</nav>

<div role="banner" id="gcwu-bnr"><div id="gcwu-bnr-in">
<div id="gcwu-title"><p id="gcwu-title-in"><a href="http://ourpch.pch.gc.ca/fra/1353586926687">Notre PCH</a></p></div>

<section role="search">
<div id="gcwu-srchbx">
<h2>Recherche</h2>
<form action="http://ourpch.pch.gc.ca/fra/1353608394203/s/q.s" method="get"><div id="gcwu-srchbx-in">
<label for="gcwu-srch">Recherche</label> <input name="l7c1l3" type="hidden" value="fra"> <input name="S_S20RCH.l1ng91g3" type="hidden" value="fra"> <input id="gcwu-srch" maxlength="150" name="S_F8LLT2XT" size="27" type="text"> 
<input id="gcwu-srch-submit" name="cn-search-submit" type="submit" value="Recherche">
</div></form>
</div>
</section>

</div></div> 
<nav>
<div id="gcwu-psnb">
<h2>Site navigation bar</h2>
<div id="gcwu-psnb-in">
<div class="wet-boew-menubar mb-mega">
<div>
<ul class="mb-menu">
<li><section>
<h3><a class="nav" href="http://ourpch.pch.gc.ca/fra/1353587823087">Le minist&egrave;re</a></h3>
<div class="mb-sm">
<div class="span-2">
<ul>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1353604849509">Coin des SMs</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1353606348084">Secteurs et directions g&eacute;n&eacute;rales</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1358530878930">Bureaux r&eacute;gionaux</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1359064138380">Groupes et comit&eacute;s</a></li>
<li><a class="nav" href="http://www.pch.gc.ca/fra/1266433674232/1266389969960">Organismes du portefeuille</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1396621064264">Nouvelles &#224; PCH</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1359120126018">En vedette</a></li>

</ul>
</div>
<div class="clear"></div>
</div>
</section></li>
<li>
<div><a class="nav" href="http://ourpch.pch.gc.ca/fra/1358683375832">Ressources humaines</a></div>
</li>
<li><section>
<h3><a class="nav" href="http://ourpch.pch.gc.ca/fra/1353594273868">Services</a></h3>
<div class="mb-sm">
<div class="span-2">

<ul>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1354728792254">AIPRP</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1433768794990">Biblioth&egrave;que</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1359122136524">Bureau des valeurs et de l'&eacute;thique</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1358684229538#1a">Centre d'accessibilit&eacute; </a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1357230196849">Centre d'expertise S et C</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1359060060923">Communications</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1359744092518">Correspondance minist&eacute;rielle</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1425496315641">Évaluations</a></li>
</ul>

</div>
<div class="span-2">

<ul>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1358684229560">Biens immobiliers et aménagement</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1355854915837">Gestion des marchés et du matériel</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1359903545873">Gestion financi&egrave;re</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1434547199704">Services DGDPI</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1359818160026">Services juridiques</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1438894248978">Stands et écrans</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1358683381079">Sécurité ministérielle</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1355144232734">V&eacute;rifications</a></li>
</ul>

</div>
<div class="clear"></div>
</div></section></li>
<li><section>
<h3><a class="nav" href="http://ourpch.pch.gc.ca/fra/1353606791530">R&eacute;f&eacute;rence et outils</a></h3>
<div class="mb-sm">
<div class="span-2">

<ul>
<li><a class="nav" href="http://sagegc-gedsgc.tpsgc-pwgsc.gc.ca/cgi-bin/web500/fra/TF?FN=index.htm">Annuaire t&eacute;l&eacute;phonique du gouvernement (SAGE)</a></li>
<li><a class="nav" href="https://portal-portail.tbs-sct.gc.ca/home-fra.aspx">Applications du SCT</a></li>
<li><a class="nav" href="https://order.translationbureau.gc.ca/">Bureau de la traduction</a></li>
<li><a class="nav" href="http://vubisweb.pch.gc.ca/iguana/www.main.cls?surl=search&p=f8616668-2589-11e5-8bee-505687299100&language=fre">Catalogue de biblioth&egrave;que</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1354743644642">CCM Mercury</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1358684229560#a1">Entretien des installations</a></li>
<li><a class="nav" href="http://gcconnex.gc.ca/">GCconnex</a></li>
<li><a class="nav" href="http://www.gcpedia.gc.ca/gcwiki/index.php?title=Main%20Page&setlang=fr&uselang=fr">GCPedia</a></li>
<li><a class="nav" href="http://mediascope.pch.gc.ca/default.asp?Lang=F">MediaScope</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1359134796078#num4">Mod&egrave;les de l'image de marque</a></li>
</ul>

</div>
<div class="span-2">

<ul>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1361977377849">Orientation des employ&eacute;s</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1358683381046">Peoplesoft</a></li>
<li><a class="nav" href="http://gcintranet.tpsgc-pwgsc.gc.ca/gc/rem/awr-cwa-fra.html">Phénix et Applications web de la rémunération</a></li>
<li><a class="nav" href="http://www.noslangues-ourlanguages.gc.ca/index-fra.php">Portail linguistique du Canada</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1359663880774">Programme d'aide aux employés</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1363374424588">R&eacute;servation de salles</a></li>
<li><a class="nav" href="http://btb.termiumplus.gc.ca/tpv2alpha/alpha-fra.html?lang=fra&amp;index=alt">Termium</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1358683381035">Urgence</a></li>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1429717894281">Voyage</a></li>
<!-- <li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1363184242329">Dictionnaires</a></li> -->
</ul>

</div>
<div class="clear"></div>
</div></section></li>
<li>
  <section>
    <h3><a class="nav" href="http://ourpch.pch.gc.ca/fra/1431449799027">Innovation</a></h3>
    <div class="mb-sm">
      <div class="span-2">
        <ul>
<li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1431449799027">Innovation à PCH</a></li>
          <li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1431027903604">Objectif 2020</a></li>
          <li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1431538821469">Fonds d'innovation</a></li>
          <li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1431109336342">Projets novateurs</a></li>
          <li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1431539569692">Succès et échecs</a></li>

          <li><a class="nav" href="http://ourpch.pch.gc.ca/fra/1431540339450">Bibliothèque </a></li>
     
        </ul>
      </div>
      <div class="clear"></div>
    </div>
  </section>
</li>
</ul>
</div>
</div>
</div>
</div>
<div id="gcwu-bc"><h2><?php print($arrTxt['breadcrumb']); ?></h2><div id="gcwu-bc-in">
	<ol>
		<li><a href="http://notrepch-ourpch/eng/1353586926687"><?php print($arrTxt['home']); ?></a></li>
		<?php
		if ($pageTitle != $arrTxt['title']) 
			print("<li><a href=\"./\">" . $arrTxt['title'] . "</a></li>");
						
		if($pageTitle == $arrTxt['viewanitem'] || $pageTitle == $arrTxt['confirmbid'] )
			print("<li><a href=\"./?category_id=all\">" . $arrTxt['categories'] . "</a></li>");

		?>
		<li><?php print($pageTitle); ?></li>
	</ol>
</div></div>

</nav> <!-- HeaderEnd -->
</header></div></div>

<div id="wb-core"><div id="wb-core-in" class="equalize">
<div id="wb-main" role="main"><div id="wb-main-in"><!-- MainContentStart -->
<h1 id="wb-cont"><?php print($pageTitle); ?></h1>
