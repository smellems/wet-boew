// JavaScript Document

 function validate_bids()
    {
      var start_price = $('#bid_start_price').val();
      var minimum_amount =  $('#minimum_amount').val();
      var bid_amount = $('#bid_amount').val(); 
      var lesserr =  $('#lesserr').val(); 
      var increrr =  $('#increrr').val(); 
      
     	if( parseFloat(bid_amount)< parseFloat(minimum_amount) )
    	{
        var p = $("<p>"); 
        p.addClass("color-attention");    
        p.text(lesserr +" : " + minimum_amount ); 
        $("div.wet-boew-formvalid").prepend(p);            
      	return false;
    	}else           
        return true;
  }
