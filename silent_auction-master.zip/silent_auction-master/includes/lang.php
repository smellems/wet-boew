<?php

  	if (isset($_GET["lang"]) && in_array($_GET["lang"], ["en", "fr"]))
  	{
  		$lang = $_GET["lang"];
  		setcookie("pchLang", $_GET["lang"], time() + 60 * 60 * 24 * 30 * 12, "/");
  	}
  	else if (isset($_COOKIE["pchLang"]) && in_array($_COOKIE["pchLang"], ["en", "fr"]))
  	{
  		$lang = $_COOKIE["pchLang"];
  		$_GET["lang"] = $_COOKIE["pchLang"];
  	}
    else {
  		$lang = "fr";
  		setcookie("pchLang", $lang, time() + 60 * 60 * 24 * 30 * 12, "/");
  		$_GET["lang"] = $lang;
	  }
    
    if (isset($_GET["email"]))
  	{
  		$email = $_GET["email"];
  		setcookie("bid_email", $_GET["email"], time() + 60 * 60 * 24 * 30 * 12, "/");
  	}else if (isset($_POST["bid_email"]))
  	{
  		$email = $_POST["bid_email"];
  		setcookie("bid_email", $_POST["bid_email"], time() + 60 * 60 * 24 * 30 * 12, "/");
  	}
  	else if (isset($_COOKIE["bid_email"]))
  	{
  		$email = $_COOKIE["bid_email"];
  	}
    else {
  		$email = "";
	  }

    
