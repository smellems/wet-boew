<div id="wb-sec"><div id="wb-sec-in"><nav><h2><?php print($arrTxt["secondarymenu"]); ?></h2>
<div class="wb-sec-def">
<!-- SecNavStart -->
<section>
<h3 class="top-section"><a class="ui-link" href="./"><?php print($arrTxt["title"]); ?></a></h3>
<section>
<h4><a class="ui-link" href="./?category_id=all"><?php print($arrTxt["categories"]); ?></a></h4>
<ul>
<?php
	$sql = "SELECT DISTINCT c.id, c.name_" . $lang . " as name
			FROM categories c, items i, auctions a
			WHERE i.category_id = c.id
			 AND i.auction_id = a.id
			 AND a.show_bids < NOW()
			 AND a.hide_bids > NOW()
			ORDER BY name;";

	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			print("<li><a class=\"ui-link\" href=\"./?category_id=" . $row["id"] . "\">" . $row["name"] . "</a></li>");
		}
	}
?>
</ul>
</section>
<section>
<h4 class="top-level"><a class="ui-link" href="./instructions.php"><?php print($arrTxt['instructions']); ?></a></h4>
</section>
</section>
<!-- SecNavEnd -->
</div>
</nav>
</div>
</div>
