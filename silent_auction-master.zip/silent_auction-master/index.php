    <?php
	// Check language
	require_once(dirname(__FILE__) . "/includes/lang.php");

	// Database connections
	require_once(dirname(__FILE__) . "/includes/database.php");

	// Include texts and header
	$leftNav = true;
	require_once(dirname(__FILE__) . "/includes/text/" . $lang . ".php");

	$pageTitle = $arrTxt['title'];
	if (isset($_GET["category_id"]) AND is_numeric($_GET["category_id"]))
	{
		$sql = "SELECT DISTINCT c.id, c.name_" . $lang . " as name
			FROM categories c, items i
			WHERE i.category_id = c.id
			AND c.id = " . $_GET["category_id"];

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) > 0) {
			$row = mysqli_fetch_assoc($result);
			$pageTitle = $row["name"];
		}
	} elseif ($_GET["category_id"] == "all") {
		$pageTitle = $arrTxt['categories'];
	}
	require_once(dirname(__FILE__) . "/includes/header-" . $lang . ".php");

	// Auctions
	$sql = "SELECT DISTINCT a.id, a.name_" . $lang . " as name, a.desc_" . $lang . " as descr, a.start, a.end, a.show_bids, a.hide_bids, a.memo_" . $lang .
			" as memo FROM items i, auctions a
			WHERE i.auction_id = a.id
			 AND a.show_bids < NOW()
			 AND a.hide_bids > NOW()
			ORDER BY name;";

	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0) {
		while($row = mysqli_fetch_assoc($result)) {
			if (!isset($_GET["category_id"])) {
				print("<h2>" . $row["name"] . "</h2>");
				print("<p>" . $row["descr"] . "</p>");
				print("<p>" . $arrTxt['startdate'] . ": <strong>" . $row["start"] . "</strong> " . $arrTxt['enddate'] . ": <strong>" . $row["end"] . "</strong></p>");
				print("<p>" . $arrTxt['showstart'] . ": <strong>" . $row["show_bids"] . "</strong> "  . $arrTxt['showend'] . ": <strong>" . $row["hide_bids"] . "</strong></p>");
				if(!empty($row["memo"]))
				   print('<div class="module-info span-6"><h2><span class="color-dark">' . $arrTxt["info"] . ': </span></h2><p>' . $row["memo"] . '</p></div><div class="clear"></div>');
			} else {
				print('<div class="wet-boew-expandcollapseall toggle-open toggle-close"></div>');

				// Categories
				$sql2 = "SELECT DISTINCT c.id, c.name_" . $lang . " as name
						FROM categories c, items i
						WHERE i.category_id = c.id";
						if (isset($_GET["category_id"]) AND is_numeric($_GET["category_id"]))
						{
							$sql2 .= " AND c.id = " . $_GET["category_id"];
						}
						$sql2 .= " AND i.auction_id = " . $row["id"];
						$sql2 .= " ORDER BY name;";

				$result2 = mysqli_query($conn, $sql2);
		
				if (mysqli_num_rows($result2) > 0) {
					while($row2 = mysqli_fetch_assoc($result2)) {
						if (!isset($_GET["category_id"]) OR $_GET["category_id"] == "all") {
							print("<h2>" . $row2["name"] . "</h2>");
						}

						// Items
						$sql3 = "SELECT id, name_" . $lang . " as name, desc_" . $lang . " as descr, price
								FROM items
								WHERE category_id = " . $row2["id"] .
								 " AND auction_id = " . $row["id"] .
								" ORDER BY name;";
					 
						$result3 = mysqli_query($conn, $sql3);
		
						if (mysqli_num_rows($result3) > 0) {
							while($row3 = mysqli_fetch_assoc($result3)) {

								// Get highest bid
								$price = $row3["price"];
								$highestBid = getHighestConfirmedBid($row3["id"]);
								if ($highestBid > $price) {
									$price = $highestBid;
								}

								$highestUnconfirmedBid = getHighestUnconfirmedBid($row3["id"]);
								$bidCount = getNumberOfConfirmedBids($row3["id"]);
               
								print("<details><summary class=\"font-large\"><strong>" . $row3["name"] . "</strong> (" . format_currency($lang,$price) . "$)");
								if ($bidCount > 1) {
									print(" - " . $bidCount . " " . $arrTxt["bid"] . "s");
								}
								elseif ($bidCount == 1) {
									print(" - " . $bidCount . " " . $arrTxt["bid"]);
								}
								print("</summary>");
								print("<p><a class=\"button button-accent\" href=\"./placer-place.php?item_id=" . $row3["id"] . "\">" . $arrTxt["viewthisitem"] . "</a></p>");
								print("<div class=\"span-2\"><img src=\"./image.php?item_id=" . $row3["id"] . "\" alt=\"" . $row3["name"] . "\" ></div>");
								print("<div class=\"span-3\">");							

								print("<p><strong>" . $arrTxt["price"] . " : " . format_currency($lang,$price) . "$</strong></p>");
								if ($highestUnconfirmedBid > 0) {
									print("<p><strong>" . $arrTxt["price"] . " : " . format_currency($lang,$highestUnconfirmedBid) . "$</strong></p>");
								}							
								print("<p>" . $row3["descr"] . "</p>");
								print("</div><div class=\"clear\"></div>");
								print("</details>");
							}
						}
					}
				}
			}

		}
	} else {
		print("<div class=\"module-attention span-6\">");
    		print("<h3>" . $arrTxt["noauctionavailable"] . "</h3>");
		print("<p>" . $arrTxt["auctionendednotstarted"] . "<p>");
    		print("</div>");
	}

	$lastmod = getlastmod();
	require_once(dirname(__FILE__) . "/includes/footer-" . $lang . ".php");

	mysqli_close($conn);
