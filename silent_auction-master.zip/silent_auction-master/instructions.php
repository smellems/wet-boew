    <?php
	// Check language
	require_once(dirname(__FILE__) . "/includes/lang.php");

	// Database connections
	require_once(dirname(__FILE__) . "/includes/database.php");

	// Include texts and header
	$leftNav = true;
	require_once(dirname(__FILE__) . "/includes/text/" . $lang . ".php");
	$pageTitle = $arrTxt['instructions'];
	require_once(dirname(__FILE__) . "/includes/header-" . $lang . ".php");
  if($lang=='en'){
  ?>
    <ul>
	  <li><a href="#rules">Auction Rules</a></li>
	  <li><a href="#process">Bidding Process</a></li>
	</ul>
	  
    <h2 id="rules">Auction Rules</h2>
    
    <ul>
    <li>Bidding for auction items is done directly from your PC;</li>
    <li>Each item has an opening bid (or starting price) and pre-determined bid increment depending on its value; </li>
    <li>If your bid is the first one, then your bid amount must be higher or equal to the coresponding item's starting price. Otherwise your bid amount must be higher than or equal to the total of the item's existing highest confirmed bid price plus its increment, which is also called minimum amout for your bid.</li>
    <li>Once a bid is submitted, it cannot be withdrawn.</li>
    <li>When an offer is made, you must confirmed it from your email by responding to the confirmation message.</li>
	<li>To keep track of an item, use the auction web URL(http://apps-notrepch-ourpch/enchere-auction/index.php) from the Intranet web site. </li>
    <li>No receipts will be provided by the GCWCC (as per standard auction practice).</li>
    <li>All proceeds from the auction will be directed to the PCH GCWCC Campaign.</li>
    <li><strong>BIDDING CLOSES AT 3:00 p.m. (sharp) on October 22, 2016. Note that the Intranet web server determines the close of the bidding.&nbsp; The clock on your PC does not necessarily have the same time as the Lotus Notes server.&nbsp; Likewise, your wrist watch does not necessarily have the same time as the bank.&nbsp; The bank determines when to close its doors according to its clock.</strong></li>
    </ul>
    
    <h2 id="process">Bidding Process</h2>
	<p>To access the application, open a web browser and copy this URL: <a href="http://apps-notrepch-ourpch/enchere-auction/index.php">http://apps-notrepch-ourpch/enchere-auction/index.php</a>.</p>
    
    <h3>To View an Item</h3>
    
    <ul>
    <li>Select a product category (e.g., <em>Articles for the house)</em>.</li>
    <li>Select an item.</li>
    </ul>
    
    <h3>To Place a Bid </h3>
 
    <ul>
      <li>Select a product category (e.g., <em>Articles for the house)</em>.</li>
      <li>Select an item.</li>
      <li>Click the button  &ldquo;Place a bid&rdquo; .</li>
      <li>Enter your email and if you want to bid a higher amount than the minimum amout, then you need to change your bid amount, and click the button &ldquo;Place a bid&rdquo;.</li>
      <li>If you want to bid another item, you can directly select the item from the drop down menu of the item name.</li>
	  <li>With the help of your e-mail, confirm your offer from the message that has been sent. Only the bids with the status 'Confirmed' will be valid</li>
    </ul>
       
    <h3>The Highest Bid</h3>
    
    <p><strong>BIDDING CLOSES AT 3:00 p.m.. (sharp - determined by server) on October 22, 2016. </strong></p>
    
    <p>The highest bid received before 3:00 p.m. on October 22 will be awarded ownership.</p>
    
    <p>The online auction will prevent you from bidding, once it has determined that the auction is over.</p>
    
    <h3>To Claim Your Item</h3>
    
    <p>Items will be available for pick-up at 25 Eddy St., 12<sup>th</sup> Floor, Station 114 between 11 AM and 1 PM on October 22, 2015.</p>
    
    <p>Cash or cheque only. Make cheque payable to the Government of Canada Workplace Charitable Campaign (GCWCC).</p>
    
    <p>Payment is <strong>due no later than Wednesday October 28, 2016.</strong></p>
    
    <p><em>NOTE: If you made a bid, you must honour it.&nbsp; NO DECLINES ACCEPTABLE.&nbsp; Payment is due no later than October 28, 2015.</em></p>
    
    <p><strong>Contacts for Auction:</strong></p>
    
    <p>Carole Whelan : 819-934-2534</p>

  
  <?php
  }else{
  ?>
    <ul>
	  <li><a href="#regle">R&egrave;glements de la vente aux ench&egrave;res</a></li>
	  <li><a href="#procedure">La proc&eacute;dure &agrave; suivre</a></li>
	</ul>
	
    <h2 id="regle">R&egrave;glements de la vente aux ench&egrave;res</h2>   
	
    <ul>
		<li>Les ench&egrave;res se feront directement de votre ordinateur.</li>
		<li>
		Un prix de d&eacute;part et une &eacute;chelle pr&eacute;-&eacute;tablie d&rsquo;augmentation de prix seront assign&eacute;s &agrave; chaque article selon la valeur de l&rsquo;article. Le prix de d&eacute;part et l&rsquo;&eacute;chelle d&rsquo;augmentation du prix seront not&eacute;s pour chaque article.
		</li>
		<li>
		Les offres doivent &ecirc;tre plus &eacute;lev&eacute;es que les offres d&eacute;j&agrave; pr&eacute;sent&eacute;es.
		</li>
		<li>
		Une fois l&rsquo;offre faite, elle ne peut &ecirc;tre ni modifi&eacute;e, ni retir&eacute;e.&nbsp;&nbsp;
		</li>
		<li>
		Lorsqu&rsquo;une offre est faite, vous devez obligatoirement la confirm&eacute;e &agrave; partir de votre courriel en r&eacute;pondant au message de confirmation.
		</li>
		<li>
		Si vous d&eacute;sirez v&eacute;rifier o&ugrave; en sont les ench&egrave;res pour un article particulier, allez sur le site de l&rsquo;encan &agrave; partir de votre espace de travail et trouver l&rsquo;article, vous pouvez utiliser le bouton de recherche.
		</li>
		<li>
		Aucun re&ccedil;u ne sera &eacute;mis par la CCMTGC (selon la pratique courante de la vente aux ench&egrave;res).
		</li>
		<li>
		Les fonds recueillis seront vers&eacute;s par PCH &agrave; la CCMTGC.
		</li>
		<li>
		<strong>La vente aux ench&egrave;res se termine &agrave; 15 h pr&eacute;cis&eacute;ment le 20 octobre 2016.&nbsp; Notez que le serveur d&eacute;termine l&rsquo;heure de cl&ocirc;ture.&nbsp; L'horloge de votre ordinateur n'a pas n&eacute;cessairement la m&ecirc;me heure que le serveur Web.&nbsp; Comme votre montre n'a pas n&eacute;cessairement la m&ecirc;me heure que la banque.&nbsp; Et la banque ferme ses portes quand elle d&eacute;termine l`heure de fermeture de la banque.</strong>
		</li>
	</ul>
	
    <h2 id="procedure">La proc&eacute;dure &agrave; suivre</h2>
    
	
    <p>Pour acc&eacute;der &agrave; l&rsquo;application, ouvrir un navigateur web, de pr&eacute;f&eacute;rence Internet Explorer et copier le lien suivant&nbsp; : <a href="http://apps-notrepch-ourpch/enchere-auction/index.php">http://apps-notrepch-ourpch/enchere-auction/index.php</a></p>
    
    <h3>Pour afficher un article</h3>
    	
	<ul>	
		<li>
		S&eacute;lectionnez une cat&eacute;gorie de produits (p. ex. <em>Articles pour la maison</em>.
		</li>
		<li>
		S&eacute;lectionnez un article.
		</li>
   </ul>
   
    <h3>Pour faire une offre</h3>
       
    <ul>
	    <li>S&eacute;lectionnez une cat&eacute;gorie de produits (p. ex. <em>Articles pour la maison)</em>.</li>
		<li>S&eacute;lectionnez un article.	</li>
		<li>Cliquez sur la touche &laquo; Faire une offre &raquo; afin d&rsquo;</li>
		<li>Inscrivez le montant de votre offre.&nbsp; Si vous &ecirc;tes le premier &agrave; faire une offre, vous pouvez offrir le prix de d&eacute;part affich&eacute; pour cet article.&nbsp;
		</li>
		<li>Inscrivez votre courriel, ceci permettra de valider votre offre et de vous identifier.
		</li>
		<li>&Agrave; l&rsquo;aide de votre courriel, confirmer votre offre &agrave; partir du message qui va a &eacute;t&eacute; envoy&eacute;.&nbsp; Seules les offres avec le statut &lsquo;<strong>confirm&eacute;</strong>&rsquo; seront valides.
		</li>
	</ul>
	
    <h3>L&rsquo;ench&egrave;re la plus &eacute;lev&eacute;e</h3>
	
    <p><strong>LES ENCH&Egrave;RES SE TERMINENT &Agrave; 15 h pr&eacute;cis&eacute;ment le 20 octobre 2016 (d&eacute;termin&eacute; par le serveur). </strong></p>
    <p>L&rsquo;article sera remis &agrave; la personne ayant fait l'offre la plus &eacute;lev&eacute;e avant 15 h 00, le 20 octobre.</p>
    <p>L'encan en ligne ne vous permettra pas de faire une offre, une fois que le serveur a d&eacute;termin&eacute; que l'encan est ferm&eacute;.</p>
    
    <h3>Pour r&eacute;clamer votre article</h3>
    <p>Tous les articles seront disponibles au 25, rue Eddy, 12<sup>ieme</sup> &eacute;tage, station 114, le 22 octobre 2016.</p>
    <p>Seuls les paiements en esp&egrave;ces ou par ch&egrave;que seront accept&eacute;s. Les ch&egrave;ques doivent &ecirc;tre libell&eacute;s &agrave; l&rsquo;ordre de la Campagne de charit&eacute; en milieu de travail du gouvernement du Canada (CCMTGC).</p>
    <p>Le paiement doit &ecirc;tre vers&eacute; au plus tard <strong>mercredi, le 26 octobre 2016</strong>.</p>
    
    <p><em>NOTE : Si vous avez fait une offre, vous devez la respecter.&nbsp; AUCUN REFUS NE SERA ACCEPT&Eacute;.&nbsp; Le paiement doit &ecirc;tre vers&eacute; au plus tard le 26 octobre 2016.</em></p>
    
    <p><strong>Personnes-ressources :</strong><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></p>
    <p>Carole Whelan 819-934-2534</p>
 

  <?php
  }
	$lastmod = getlastmod();
	require_once(dirname(__FILE__) . "/includes/footer-" . $lang . ".php");

	mysqli_close($conn);
  ?>