<?php
	// Check language
  session_start();
  if(isset($_GET['logout'])){
		session_unset();
		session_destroy();
  }
  require_once(dirname(__FILE__) . "/includes/lang.php");
  
  // Database connections
  require_once(dirname(__FILE__) . "/includes/database.php");

  $leftNav = false;
 
  // Include texts and header
  require_once(dirname(__FILE__) . "/includes/text/" . $lang . ".php");

  // PHPMailer
  require_once(dirname(__FILE__) . "/lib/PHPMailer/PHPMailerAutoload.php");
  
  $pageTitle = 'Manage items';
  require_once(dirname(__FILE__) . "/includes/header-" . $lang . ".php");
  date_default_timezone_set("America/Toronto");
  
  if (isset($_POST['nom']) && isset($_POST['pwd'])) {
	if(empty($_POST['nom']) ||  empty($_POST['pwd'])){
		if(empty($_POST['nom']))
			echo '<p><strong>You need to type the user name!</strong></p>';
		if(empty($_POST['pwd']))
			echo '<p><strong>You need to type the password!</strong></p>';
	}else{
		$sqll = 'SELECT Password FROM mysql.user where User="' . $_POST['nom'] . '"';
		
		$resl = mysqli_query($conn, $sqll);
		if ($row = mysqli_fetch_assoc($resl))
		 {
			 if(mysqli_connect($servername,$_POST['nom'], $_POST['pwd'], $dbname))
			 {
				 if(!isset($_SESSION['username']))
				  $_SESSION['username'] = $_POST['nom'];
				 if(!isset($_SESSION['password']))
				  $_SESSION['password'] = $_POST['pwd'];
			}else{
				echo '<p><strong>The password is not correct, please confirm!</strong></p>';
			}
		}else
		   echo '<p><strong>This user is not registed yet! please register first!</strong></p>';
	}		
  }
  
  $auction = [];
  $categories =[];
 
  $sql = "SELECT id, name_en as name FROM auctions"; 
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0)
  {
	  while ($row = mysqli_fetch_assoc($result))
	  {
		$auction[$row['name']] = $row['id'];
		
	  }
  }
 
  $sql = "SELECT id, name_en as name FROM categories"; 
  $result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0)
  {
	  while ($row = mysqli_fetch_assoc($result))
	  {
		$categories[$row['name']] = $row['id'];
		
	  }
  }
  
  if(isset($_GET['act'])){
	 $act = $_GET['act'];
	 if($act=="add"){
		 $imgFile = $_FILES['img']['name'];
         $tmp_dir = $_FILES['img']['tmp_name'];
         $imgSize = $_FILES['img']['size'];		 
		 if($_POST['aid']=="Select an auction" || $_POST['cid']=="Select a category" || empty($_POST['fname']) || empty($_POST['ename']) 
			 || empty($_POST['fdsc']) || empty($_POST['edsc']) || $_POST['price']==0 || empty($_POST['price']) || $_POST['incres']==0 || empty($_POST['incres']) || !$imgFile){
			 if($_POST['aid']=="Select an auction") 
			     echo '<p><strong>You need to select an auction!</strong></p>';
			 if($_POST['cid']=="Select a category") 
			    echo '<p><strong>You need to select a category!</strong></p>';
			 if(empty($_POST['fname']))
			    echo '<p><strong>You need to type the French name!</strong></p>'; 
			 if(empty($_POST['ename']))
			    echo '<p><strong>You need to type the English name!</strong></p>'; 
			 if(empty($_POST['fdsc']))
			    echo '<p><strong>You need to type the French description!</strong></p>'; 
			 if(empty($_POST['edsc']))
			    echo '<p><strong>You need to type the Englishdescription!</strong></p>'; 			
			 if(empty($_POST['price']) || $_POST['price']==0)
				 echo '<p><strong>You need to type the price!</strong></p>'; 
			 if(empty($_POST['incres']) || $_POST['incres']==0)
				 echo '<p><strong>You need to type the increments!</strong></p>'; 
			 if(!$imgFile)
			     echo '<p><strong>You need to upload the picture!</strong></p>'; 
		 }else{				   
			   $upload_dir = './includes/images/'; // upload directory 
			   $imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
			   $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions			   
			   $picdata = file_get_contents($tmp_dir);		   
			  
			   
			   if(!in_array($imgExt, $valid_extensions) || $imgSize > 5000000)
			   {   
				if($imgSize > 5000000)
				   echo '<p><strong>The picture is too large, it should be less than 5M !</strong></p>'; 
				if(!in_array($imgExt, $valid_extensions))
				   echo '<p><strong>Only JPG, JPEG, PNG & GIF are allowed!</strong></p>'; 			
			   }
			   else{	
			       $bindata = mysqli_real_escape_string($conn, $picdata);
				   move_uploaded_file($tmp_dir,$upload_dir.$imgFile);	
				   $sqlc = 'INSERT INTO items VALUES(NULL,' . $_POST['aid'] . ', ' . $_POST['cid'] . ',"' . $_POST['fname'] . '","' . $_POST['ename'] . '","' . $_POST['fdsc'] . '","' . $_POST['edsc'] . '",' . $_POST['price'] . ', ' . $_POST['incres'] . ',"' . $bindata . '",now(), NULL)';
				   $resultc = mysqli_query($conn, $sqlc);
				   if($resultc) 
						 echo '<p><strong>A new item is added successfully!</strong></p>';	 
				   else
						 echo mysqli_error($sqlc);  
				}
		 }
  
	 }else if($act=="del"){
		$id = $_GET['checkindex'];
		$sqlc = 'delete from items where id=' . $id;
 		$resultc = mysqli_query($conn, $sqlc);
		if($resultc) 
			 echo '<p><strong>Item ' . $id . ' is deleted successfully!</strong></p>';	 
		else
			 echo mysqli_error($sqlc);  		
	 }else if($act=="save"){
		 $id = $_GET['checkindex'];
		 $img =  'img' . $id;
		 $aid = 'aid' . $id;
		 $cid  = 'cid' . $id;
		 $fname = 'fname' . $id;
		 $ename = 'ename' . $id;		
		 $fdsc = 'fdsc' . $id;
		 $edsc = 'edsc' . $id;
		 $price = 'price' . $id;
		 $incres = 'incres' . $id;
		
		 $imgFile = $_FILES[$img]['name'];
		 $tmp_dir = $_FILES[$img]['tmp_name'];
		 $imgSize = $_FILES[$img]['size'];		 
		 if($_POST[$aid]=="Select an auction" || $_POST[$cid]=="Select a category" || empty($_POST[$fname]) || empty($_POST[$ename]) 
			 || empty($_POST[$fdsc]) || empty($_POST[$edsc]) || $_POST[$price]==0 || empty($_POST[$price]) || $_POST[$incres]==0 || empty($_POST[$incres])){
			 if($_POST[$aid]=="Select an auction") 
			     echo '<p><strong>You need to select an auction for item ' . $id . '!</strong></p>';
			 if($_POST[$cid]=="Select a category") 
			    echo '<p><strong>You need to select a category for item ' . $id . '!</strong></p>';
			 if(empty($_POST[$fname]))
			    echo '<p><strong>You need to type the French name for item ' . $id . '!</strong></p>'; 
			 if(empty($_POST[$ename]))
			    echo '<p><strong>You need to type the English name for item ' . $id . '!</strong></p>'; 
			 if(empty($_POST[$fdsc]))
			    echo '<p><strong>You need to type the French description for item ' . $id . '!</strong></p>'; 
			 if(empty($_POST[$edsc]))
			    echo '<p><strong>You need to type the Englishdescription for item ' . $id . '!</strong></p>'; 			
			 if(empty($_POST[$price]) || $_POST[$price]==0)
				 echo '<p><strong>You need to type the price for item ' . $id . '!</strong></p>'; 
			 if(empty($_POST[$incres]) || $_POST[$incres]==0)
				 echo '<p><strong>You need to type the increments for item ' . $id . '!</strong></p>'; 
		 }else{		
               if($imgFile){		 
				   $upload_dir = './includes/images/'; // upload directory 
				   $imgExt = strtolower(pathinfo($imgFile,PATHINFO_EXTENSION)); // get image extension
				   $valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions			   
				   $picdata = file_get_contents($tmp_dir);		   
							   
				   if(!in_array($imgExt, $valid_extensions) || $imgSize > 5000000)
				   {   
					if($imgSize > 5000000)
					   echo '<p><strong>The picture is too large, it should be less than 5M for item ' . $id . '!</strong></p>'; 
					if(!in_array($imgExt, $valid_extensions))
					   echo '<p><strong>Only JPG, JPEG, PNG & GIF are allowed for item ' . $id . '!</strong></p>'; 			
				   }
				   else{	
					   $bindata = mysqli_real_escape_string($conn, $picdata);
					   move_uploaded_file($tmp_dir,$upload_dir.$imgFile);	
					   $sqlc = 'update items set auction_id=' . $_POST[$aid] . ', category_id=' . $_POST[$cid] . ',name_fr="' . $_POST[$fname] . '",name_en="' . $_POST[$ename] . '",desc_fr="' . $_POST[$fdsc] . '",desc_en="' . $_POST[$edsc] . '",price=' . $_POST[$price] . ',increments=' . $_POST[$incres] . ',picture="' . $bindata . '",modified=now() where id=' . $id;
					   $resultc = mysqli_query($conn, $sqlc);
					   if($resultc) 
							 echo '<p><strong>Item ' . $id . ' is updated successfully!</strong></p>';	 
					   else
							 echo mysqli_error($sqlc);  
					}
			}else{
				   $sqlc = 'update items set auction_id=' . $_POST[$aid] . ', category_id=' . $_POST[$cid] . ',name_fr="' . $_POST[$fname] . '",name_en="' . $_POST[$ename] . '",desc_fr="' . $_POST[$fdsc] . '",desc_en="' . $_POST[$edsc] . '",price=' . $_POST[$price] . ',increments=' . $_POST[$incres] . ',modified=now() where id=' . $id;
				   $resultc = mysqli_query($conn, $sqlc);
				   if($resultc) 
						 echo '<p><strong>Item ' . $id . ' is updated successfully!</strong></p>';	 
				   else
						 echo mysqli_error($sqlc);  
			}				
		 }  
	 }
  }
  if(isset($_SESSION['username']) && isset($_SESSION['password'])) {
?>
   <p><strong><a href="items.php?logout=true">Log out</a></strong></p>
	<form name="frm_items" enctype="multipart/form-data" action="items.php" method="post">
       <table class="wet-boew-tables" data-wet-boew='{"bSort": false}'>
	   <thead>
	     <tr>
		    <th>&nbsp;</th>
		    <th>Item ID</th>
			<th>Auction ID</th>
			<th>Category ID</th>
		    <th>French name</th>
			<th>English name</th>
		    <th>French Description</th>
			<th>English Description</th>
			<th>Price</th>
			<th>Increments</th>
			<th>Picture</th>
			<th>Date created</th>
			<th>Date modified</th>
			<th>Actions</th>
		 </tr>
		 </thead>
		 <tbody>
		 <?php
			if(isset($_GET['checkindex']) && $_GET['checkindex']==0){
				print('<tr class="background-highlight">');
			    print('<td><input type="radio" checked name="checkindex" value="0" onchange="window.location.href=\'items.php?checkindex=\'+this.value"></td>');
			}
			else{
				print('<tr>');		 
				print('<td><input type="radio" name="checkindex" value="0" onchange="window.location.href=\'items.php?checkindex=\'+this.value"></td>');
			}
		 ?>
		 <!--
		    <td><input type="radio" name="checkindex" value="0" onchange="window.location.href='items.php?checkindex='+this.value"></td>
	     -->	 
    		<td>&nbsp;</td>
		    <td>
			   <select id="aid" name="aid">
			   <option value="Select an auction">Select an auction</option>
				<?php 
				  foreach($auction as $x => $x_value) {
					  if($x_value==$_POST['aid'])
					      print ('<option selected="selected" value=' . $x_value . '>' . $x . '</option>');
					  else
						  print ('<option value=' . $x_value . '>' . $x . '</option>');
				  }
		         ?>         
		        </select>
			</td>
		    <td>
			   <select id="cid" name="cid">
			   <option value="Select a category">Select a category</option>
				<?php 
				  foreach($categories as $x => $x_value) {
					  if($x_value==$_POST['cid'])
					       print ('<option selected="selected" value=' . $x_value . '>' . $x . '</option>');
					   else
						   print ('<option value=' . $x_value . '>' . $x . '</option>');
				  }
		         ?>         
		        </select>
			</td>
            <td><input type="text" name="fname" size=50 value="<?php if(isset($_POST['fname'])) print($_POST['fname']);?>"></td>
            <td><input type="text" name="ename" size=50 value="<?php if(isset($_POST['ename'])) print($_POST['ename']);?>"></td>	
            <td><input type="text" name="fdsc" size=50 value="<?php if(isset($_POST['fdsc'])) print($_POST['fdsc']);?>"></td>
            <td><input type="text" name="edsc" size=50 value="<?php if(isset($_POST['edsc'])) print($_POST['edsc']);?>"></td>	
            <td><input type="number" step=0.01 size=5 name="price" value="<?php if(isset($_POST['price'])) print($_POST['price']);?>" ></td>
			<td><input type="number" step=0.01 size=5 name="incres" value="<?php if(isset($_POST['incres'])) print($_POST['incres']);?>" ></td>
			<td><input type="file" name="img" accept="image/*" ></td>
 			<td>&nbsp;</td>
			<td>&nbsp;</td>
			<td>
			    <input type="submit" value="Add" onclick="frm_items.action='items.php?act=add'; return true;" />
			</td>
		 </tr>	
         <?php
		    
           	$sql = 'select id, auction_id as aid, category_id as cid, name_fr,name_en, desc_fr, desc_en, price, increments, picture, created, modified from items' ;
			$result = mysqli_query($conn, $sql);
			if (mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_assoc($result)) {
					$id = $row["id"];
					$fname =  $row["name_fr"];
					$ename =  $row["name_en"];
					$fdsc =  $row["desc_fr"];
					$edsc =  $row["desc_en"];
					$price =  $row["price"];
					$incres =  $row["increments"];
					$pic =  $row["picture"];
					$creat = $row["created"];
					$modi =  $row["modified"];
					if(isset($_GET['checkindex']) && $_GET['checkindex']==$id){
						print('<tr class="background-highlight">');
						print('<td><input type="radio" checked name="checkindex" value="' . $id . '" onchange="window.location.href=\'items.php?checkindex=\'+this.value"> </td>');
					}
					else{
						print('<tr>');
						print('<td><input type="radio" name="checkindex" value="' . $id . '" onchange="window.location.href=\'items.php?checkindex=\'+this.value"> </td>');
					}
					
     	?>
				    <td> <?php print($row["id"]); ?>  </td>
					<td>
					   <select name="<?php print ('aid' . $id); ?>">
					   <option value="Select auction ID">Select the auction</option>
						<?php 
						  foreach($auction as $x => $x_value) {
							  if($x_value==$row['aid'])
							       print ('<option selected="selected" value=' . $x_value . '>' . $x . '</option>');
							  else 
								   print ('<option value=' . $x_value . '>' . $x . '</option>');
						  }
						 ?>         
						</select>
					</td>
					<td>
					   <select name="<?php print ('cid' . $id); ?>">
					   <option value="Select auction ID">Select the category</option>
						<?php 
						  foreach($categories as $x => $x_value) {							  
							  if($x_value==$row['cid'])
							       print ('<option selected="selected" value=' . $x_value . '>' . $x . '</option>');
							  else 
								   print ('<option value=' . $x_value . '>' . $x . '</option>');
						  }
						 ?>         
						</select>
					</td>
					<td><input type="text" size=50 name="<?php print ('fname' . $id); ?>" value="<?php print $fname ?>"></td>
					<td><input type="text" size=50 name="<?php print ('ename' . $id); ?>" value="<?php print $ename ?>"></td>	
					<td><input type="text" size=50 name="<?php print ('fdsc' . $id); ?>" value="<?php print $fdsc ?>"></td>
					<td><input type="text" size=50 name="<?php print ('edsc' . $id); ?>" value="<?php print $edsc ?>"></td>	
					<td><input type="number" step=0.01 size=5 name="<?php print ('price' . $id); ?>" value="<?php print $price ?>"></td>
					<td><input type="number" step=0.01 size=5 name="<?php print ('incres' . $id); ?>" value="<?php print $incres ?>"></td>
					<td><input type="file" name="<?php print ('img' . $id); ?>" accept="image/*" ><?php print("<img width=\"50\" height=\"50\" src=\"./image.php?item_id=" . $row["id"] . "\" alt=\"" . $row["name_en"] . "\" >"); ?></td>
					<td><?php print $creat ?></td>
					<td><?php print $modi ?></td>	
				    <td>
				     <input type="submit" value="Save"  onclick="frm_items.action='items.php?act=save&checkindex=<?php print($id); ?>'; return true;" />
					 <input type="submit" value="Delete" onclick="frm_items.action='items.php?act=del&checkindex=<?php print($id); ?>'; return true;" />
				    </td>
				</tr>
        <?php		
				}
            }
		 ?>		
        </tbody>		 
	   </table>  
		
    </form>
 <?php
  }else{
?>      
	<form name="frm_login" method="post" action="items.php">
		<input type="hidden" id="srt" name="srt" value="">
		<label for="nom">User name:</label>
		<input type="text" id="nom" name="nom" size="50"><br><br>
		<label for="pwd">Password:</label>
		<input type="password" id="pwd" name="pwd" size="50"><br><br>
		<input type="submit" value="Login">
	</form> 

<?php
    }    
     $lastmod = getlastmod();
     require_once(dirname(__FILE__) . "/includes/footer-" . $lang . ".php");
     
     mysqli_close($conn);
?>
 

