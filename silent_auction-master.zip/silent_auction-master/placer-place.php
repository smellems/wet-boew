   <?php
	// Check language
  require_once(dirname(__FILE__) . "/includes/lang.php");
  
  // Database connections
  require_once(dirname(__FILE__) . "/includes/database.php");

  $leftNav = true;
 
  // Include texts and header
  require_once(dirname(__FILE__) . "/includes/text/" . $lang . ".php");

  // PHPMailer
  require_once(dirname(__FILE__) . "/lib/PHPMailer/PHPMailerAutoload.php");
  
  $pageTitle = $arrTxt['viewanitem'];
  require_once(dirname(__FILE__) . "/includes/header-" . $lang . ".php");
  date_default_timezone_set("America/Toronto");
  //print('<p><a href="./">' . $arrTxt["backtohome"] . '</a></p>');
  $errHead = '<div class="module-alert span-6"><h2><span class="color-dark">' . $arrTxt["error"] . ': </span>';
  $infoHead = '<div class="module-info span-6"><h2><span class="color-dark">' . $arrTxt["info"] . ': </span>';
  
  //begin confirming the bid 
  if(isset($_GET['hash_code'])){
    $pageTitle = $arrTxt['confirmbid'];
    $hash_code = $_GET['hash_code'];
    $row = getBidInfoByHashCode($hash_code);
    if($row ==0){
       $item_id = 0;
       $status = 0;
       $price = 0;
    }else{
       $item_id = $row['item_id'];
       $status = $row['status'];  
       $price = $row['price']; 
    }     
    $auction_id = getAuctiobId($item_id);
	if($dts = getDates($auction_id)){
		   $start_time = $dts["start"];
		   $end_time =  $dts["end"];
    }else{
		   $start_time = "9999";
		   $end_time = "0000";
	}
	$cur_time = date('Y-m-d H:i:s', time()); 
    $item_name = getItemName($item_id, $lang);
    
    if($item_id>0 && $cur_time>$start_time && $cur_time<$end_time){
        if($status==1 || $status==2){
			if(isset($_GET['decline'])) 
				print( $infoHead . $arrTxt["alreadydeclined"] . '</h2>'
                     . '<p>' . $arrTxt['itemname'] . ' : ' . $item_name . '<br>'
                     . $arrTxt["price"] . ' : ' . $price . '$</p></div><div class="clear"></div>'
                     );
			else
				print( $infoHead . $arrTxt["alreadyconfirmed"] . '</h2>'
                     . '<p>' . $arrTxt['itemname'] . ' : ' . $item_name . '<br>'
                     . $arrTxt["price"] . ' : ' . $price . '$</p></div><div class="clear"></div>'
                     );
			   
        }else{
			$sql = "";
			if(isset($_GET['decline']))	
				$sql = "update bids set modified=NOW(), status=2 where hash_code=" . $hash_code;
			else
				$sql = "update bids set modified=NOW(), status=1 where hash_code=" . $hash_code;
			
           $result = mysqli_query($conn, $sql);
           if($result){
				if(isset($_GET['decline']))	
					print( $infoHead . $arrTxt["declinesuccess"] . '</h2>'
                     . '<p>' . $arrTxt['itemname'] . ' : ' . $item_name . '<br>'
                     . $arrTxt["price"] . ' : ' . $price . '$</p></div><div class="clear"></div>'
                     );
				else
					print( $infoHead . $arrTxt["confirmsuccess"] . '</h2>'
                     . '<p>' . $arrTxt['itemname'] . ' : ' . $item_name . '<br>'
                     . $arrTxt["price"] . ' : ' . $price . '$</p></div><div class="clear"></div>'
                     );
           }else{
				if(isset($_GET['decline']))	
					print( $errHead . $arrTxt["declinefailed"] . '</h2>'
                     . '<p>' . $arrTxt['itemname'] . ' : ' . $item_name . '<br>'
                     . $arrTxt["price"] . ' : ' . $price . '$</p></div><div class="clear"></div>'
                     );
                else
  					print( $errHead . $arrTxt["confirmfailed"] . '</h2>'
                     . '<p>' . $arrTxt['itemname'] . ' : ' . $item_name . '<br>'
                     . $arrTxt["price"] . ' : ' . $price . '$</p></div><div class="clear"></div>'
                     );
           }
        }
    }else{
		if(isset($_GET['decline'])) 
			print( $errHead . $arrTxt["declinefailed"] . '</h2>' . '<p>' . $arrTxt["auctionendednotstarted"] . '</p></div><div class="clear"></div>');		
	    else
			print( $errHead . $arrTxt["confirmfailed"] . '</h2>' . '<p>' . $arrTxt["auctionendednotstarted"] . '</p></div><div class="clear"></div>');
      }       
  }else{
     if (isset($_GET['item_id']))     
      $item_id = $_GET['item_id'];
     else if(isset($_POST['bid_item_id']))
      $item_id = $_POST['bid_item_id'];
     else if(isset($_POST['item_id']))
      $item_id = $_POST['item_id'];
     else 
      $item_id = 1;
  
  }
  //end confirming the bid
  
  //begin initialization 
  
  $item_name = getItemName($item_id, $lang);
  $validemail = true;
  $validbid = true;
  $errFlag = 0;
  
  $auction_id = getAuctiobId($item_id);
  if($dts = getDates($auction_id)){
	   $start_time = $dts["start"];
	   $end_time =  $dts["end"];
	   $show_bids = $dts["show_bids"];
	   $hide_bids = $dts["hide_bids"];
  }else{
	   $start_time = "9999";
	   $end_time = "0000";
	   $show_bids = "9999";
	   $hide_bids = "0000";
  }
  $row = getPriceAndIncrementsFromItems($item_id);
  if($row ==0){
     $start_price = 0;
     $increments = 0;
  }else{
     $start_price = $row['price'];
     $increments = $row['increments'];  
  }      
  $highest_confirmed = getHighestConfirmedBid($item_id);
  $highest_unconfirm = getHighestUnconfirmedBid($item_id);
  
  if($highest_confirmed==0)
     $minimum_amount = $start_price; 
  else 
     $minimum_amount = $highest_confirmed + $increments;
           
  //end initialization
  
  //begin submitting the form
  if(isset($_POST['submit'])){  
      $insert_status = false;   
      $sendmail_status = false;           
      $cur_time = date('Y-m-d H:i:s', time());    
      if($cur_time<=$end_time && $cur_time>=$start_time){
          $errMsg = "";
          if($lang=="fr")
             $bidmnt = str_replace(",",".", $_POST["bid_amount"]);
          else 
             $bidmnt =  $_POST["bid_amount"];
          // validate bid amount
          if(empty($_POST["bid_amount"])){
               $validbid = false;
               $errMsg = $errMsg . $arrTxt["bidamount"] . " - " . $arrTxt["thefield"] . $arrTxt["isrequired"] . '##';
          }else{
                if(is_numeric($bidmnt)){
                    $new_highest = getHighestConfirmedBid($item_id);
                    $newminimum = $new_highest + $_POST['increments'];
                    if($new_highest>$highest_confirmed){
                        if($bidmnt<$newminimum){
                          $validbid = false;
                          $errFlag = 1;
                          $errMsg = $errMsg . $arrTxt["toolate"] . '##';
                        }
                       $highest_confirmed = $new_highest;
                       $minimum_amount = $newminimum;
                    }else{
                         if($bidmnt<$minimum_amount){
                            $validbid = false;
                            $errFlag = 2;
                            $errMsg = $errMsg . $arrTxt["greaterthan"] . '##';
                        }        
                    }
                 }else{
                     $validbid = false;
                     $errMsg = $errMsg . $arrTxt["bidamount"] . " - " . $arrTxt["thefield"] . $arrTxt["isinvalid"] . '##';
                 }
          }
          // validate email
          if(empty($_POST["bid_email"])){
               $validemail = false;
               $errMsg = $errMsg  .  $arrTxt["email"] . " - " . $arrTxt["thefield"] . $arrTxt["isrequired"] . '##';
          }
          else{
              $email = test_input($_POST["bid_email"]);
              $validemail = filter_var($email, FILTER_VALIDATE_EMAIL);
              if(!$validemail)
                  $errMsg = $errMsg  . $arrTxt["email"] . " - " . $arrTxt["thefield"] . $arrTxt["isinvalid"] . '##';  
          }
          
          // insert into database        
          if($validemail && $validbid){
              $hash_code = round(microtime(true) * 1000);	
              $sql = 'INSERT INTO bids(id,item_id,email,price,hash_code,status,created,modified) VALUES(NULL,' . $item_id . ',"' . $email . '",' . $bidmnt . ',"' . $hash_code . '"' . ', false, NOW(), NULL)';
              $result = mysqli_query($conn, $sql);
              if($result){ 
                 $insert_status = true;
                 $highest_unconfirm = getHighestUnconfirmedBid($item_id);
                 }
              else
                 $errMsg = $errMsg . mysqli_error($sql) . '##';  
          }
            
          // send email          
          if($insert_status){
              $mail = new PHPMailer;
              $mail->CharSet = 'UTF-8';
              $mail->isSMTP();
              $mail->Host = 'msa.in.pch.gc.ca';
              $mail->Port = 587;                      
              $mail->SMTPAuth = false;
              $mail->From = 'bobby.tan@canada.ca';
              $mail->FromName = 'Bobby Tan';
              $mail->addAddress($_POST['bid_email']);
              $mail->isHTML(true);         
              $mail->Subject = $arrTxt["confirmbid"];
              
              $created = getCreatedByHashCode($hash_code);
              $msg ="<p><strong>" . $arrTxt["hintmsg"] . "<br><br>"
                    . $arrTxt['itemname'] . " : " . $item_name . "<br>"
                    . $arrTxt["email"] . " : " . $_POST['bid_email'] . "<br>"
                    . $arrTxt["created"] . " : " . $created . "<br>"
                    . $arrTxt["price"] . " : " . $_POST['bid_amount']  . "$</strong></p>"
                    . '<p><a href="http://' . $_SERVER['HTTP_HOST'] . getSitePath() . '/placer-place.php?hash_code=' . $hash_code . '&email=' . $_POST['bid_email'] . '">' . $arrTxt["confirmlnk"] . '</a></p> '
                    . '<p><a href="http://' . $_SERVER['HTTP_HOST'] . getSitePath() . '/placer-place.php?hash_code=' . $hash_code . '&decline=true&email=' . $_POST['bid_email'] . '">' . $arrTxt["declinebid"] . '</a></p> '
                    . "<p><strong>" . $arrTxt["warnmsg"] . "</strong></p>";
                     
              $mail->Body = $msg;
              
              if(!$mail->send()) {
                   print($errHead . $arrTxt["senderror"] . '</h2>'
                    . '<p>' .  $mail->ErrorInfo  . '</p></div><div class="clear"></div>');
             }else{
                  print($infoHead . $arrTxt["sendmail"] . '</h2>'
                    . '<p>' . $arrTxt['itemname'] . ' : ' . $item_name . '<br>'
                    . $arrTxt["email"] . ' : '  . $_POST['bid_email'] . '<br>'
                    . $arrTxt["created"] . ' : '  . $created . '<br>'
                    . $arrTxt["price"] . ' : '  . $_POST['bid_amount']  . '$</p></div>');
                  
             }           
           }  
      }
      else{
           $errMsg = $errMsg . $arrTxt["auctionend"] . '##';
      } 
      
      if(!empty($errMsg)){
         $errMsg = substr($errMsg, 0, strlen($errMsg)-2);        
         $pieces = explode("##", $errMsg);
         $arrlen = count($pieces);
         $outStr = "";
         for($x=0; $x<$arrlen;$x++)
            $outStr = $outStr . '<li>' . $pieces[$x] . '</li>';       
         
         print($errHead . $arrTxt["submitfailed"] . '</h2>'
                    . '<ul>' .  $outStr  . '</ul></div>');
      }
       
  }
   // end submitting the form
   
   $cur_time = date('Y-m-d H:i:s', time());    
   if($cur_time>$show_bids && $cur_time<$hide_bids){
	  if($cur_time<$start_time || $cur_time>$end_time)
		print($infoHead . $arrTxt["noauctionavailable"] . ': </span></h2><p>' . $arrTxt["auctionendednotstarted"] . '</p></div><div class="clear"></div>');
?>
  	     
      <form name="form_bid" id="form_bid" method="post" action="placer-place.php">
          <input type="hidden" id="increments" name="increments" value="<?php print($increments); ?>"> 
          
        <noscript>   
          <input type="hidden" id="item_id" name="item_id" value="<?php print($item_id); ?>">
          <label for="bid_item_name"><?php print($arrTxt['itemname']); ?> :</label>
          <input type="text"  id="bid_item_name" name="bid_item_name" size=85 value="<?php print($item_name); ?>" disabled >
        </noscript>
        
        <div class="biditem">   
          <label for="bid_item_id"><?php print($arrTxt['itemname']); ?> :</label>          
          <select class="background-highlight" id="bid_item_id" name="bid_item_id" onChange="window.location.href='placer-place.php?item_id='+this.value">
          <?php 
              $sql = "SELECT i.id, i.name_" . $lang . " as name	FROM items i, auctions a where i.auction_id=a.id and a.show_bids < NOW() and a.hide_bids > NOW() order by name";
			  $result = mysqli_query($conn, $sql);
              if (mysqli_num_rows($result) > 0) {
						    while($row = mysqli_fetch_assoc($result)) {
                  if($row['id']==$item_id)
                     print('<option selected="selected" value="' . $row['id'] . '">' . $row['name'] . '</option>');
                  else
                    print('<option value="' . $row['id'] . '">' . $row['name'] . '</option>');
                }
              }
          ?>
          </select>
        </div>
        
          <label><?php print($arrTxt['startprice'] . ' : ' . format_currency($lang,$start_price)); ?> $</label>
        	<input type="hidden" id="bid_start_price" name="bid_start_price" value="<?php print($start_price); ?>"> 

          <label><?php print($arrTxt['confirmedhighest'] . ' : ' . format_currency($lang,$highest_confirmed)); ?>$</label>
         	<input type="hidden" id="highest_confirmed" name="highest_confirmed" value="<?php print($highest_confirmed); ?>"> 

          <label><?php print($arrTxt['unconfirmhighest'] . ' : ' . format_currency($lang,$highest_unconfirm)); ?>$</label>
         	<input type="hidden" id="highest_unconfirm" name="highest_unconfirm" value="<?php print($highest_unconfirm); ?>"> 

          <label><?php print($arrTxt['minimumamount'] . ' : ' . format_currency($lang,$minimum_amount)); ?>$</label>
        	<input type="hidden" id="minimum_amount" name="minimum_amount" value="<?php print($minimum_amount); ?>"> 

          <label for="bid_amount"><span class="field-name"><?php print($arrTxt['bidamount']); if($lang=="en") print(" (format: 9999.99)"); else print(" (format : 9999,99)") ?> </span> $ <strong>(<?php print($arrTxt['required']); ?>)</strong>
          <?php 
            if(!$validbid){
              if(empty($_POST["bid_amount"]))
                  print('<br><strong class="error"><span class="prefix">' . $arrTxt["error"] . ' : </span>' . $arrTxt["requiredfield"] . '</strong>' );
              else{
                  if($errFlag==2)    
                      print('<br><strong class="error"><span class="prefix">' . $arrTxt["error"] . ' : </span>' . $arrTxt["greaterthan"] . '</strong>' );
                  else if($errFlag==1)
                      print('<br><strong class="error"><span class="prefix">' . $arrTxt["error"] . ' : </span>' . $arrTxt["toolate"] . '</strong>' );
                  else
                      print('<br><strong class="error"><span class="prefix">' . $arrTxt["error"] . ' : </span>' . $arrTxt["invalidfield"] . '</strong>' );
                  }
            } 
          ?>
          </label>
          <?php 
             if(isset($_POST['bid_amount'])){
                if(is_numeric($bidmnt))
                    print('<input type="text" id="bid_amount" name="bid_amount" value="' . format_currency($lang,$bidmnt) . '">' );
                else
                    print('<input type="text" id="bid_amount" name="bid_amount" value="' . $_POST['bid_amount'] . '">' );
             }else
                print('<input type="text" id="bid_amount" name="bid_amount" value="' . format_currency($lang,$minimum_amount) . '">' );
          ?>
             
          <label for="bid_email"><span class="field-name"><?php print ($arrTxt['email'] . ' ' . $arrTxt["yourname"]); ?> </span> <strong>(<?php print($arrTxt['required']); ?>)</strong>
          <?php 
		    print('<br><strong>' . $arrTxt["makesure"] . '</strong>');
            if(!$validemail){
               if(empty($_POST["bid_email"]))
                  print('<br><strong class="error"><span class="prefix">' . $arrTxt["error"] . ' : </span>' . $arrTxt["requiredfield"] . '</strong>' );
               else
                  print('<br><strong class="error"><span class="prefix">' . $arrTxt["error"] . ' : </span>' . $arrTxt["invalidfield"] . '</strong>' );
            } 
          ?>
          </label>
          <input type="text" id="bid_email" name="bid_email" size=50 value="<?php print($email); ?>" >
                           
          <div class="form-inline margin-top-large">
		  <?php
		     if($cur_time<$end_time && $cur_time>$start_time){
		  ?>
               <input type="submit" name="submit" id="submit" value="<?php print $arrTxt['placebid']; ?>" class="button button-accent"/>
	      <?php
			 }else{     
		  ?>		 
	           <input type="submit" name="submit" id="submit" value="<?php print $arrTxt['placebid']; ?>" class="button button-disabled" disabled />
		   <?php
			 }
            ?>			 
	
 		  </div>
		  
		 </form>
  

   <?php
     
         require_once(dirname(__FILE__) . "/includes/afficher-display.php");   
     }	 
     $lastmod = getlastmod();
     require_once(dirname(__FILE__) . "/includes/footer-" . $lang . ".php");
     
     mysqli_close($conn);
   ?>
 

